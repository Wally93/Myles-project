<?php
include_once 'includes/functions.php';
?>
<!DOCTYPE html>
<html lang='en'>
    <head>
    	<style>

    	ul{
    		list-style-position: inside;
    	}

    	#information{
    		background-color: #FFFFFF;
    		color:#1577A6;
    		font-family: "Goudy Bookletter 1911",sans-serif;
    		font-weight: bold;
    		width:45%;
    		text-align: left;
    		border-radius: 20px;
    		padding-bottom: 5px;
    		padding-top: 5px;
    		padding-left: 5px;
    		/*-webkit-animation-delay: .25s;
    		animation-delay: .25s;
    		-webkit-animation: mymove 1s; /* Chrome, Safari, Opera */
  			/*animation: mymove 1s; */
  		}

    	#instructions{
    		background-color: white;
    		width:45%;
    		text-align: left;
    		color:#1577A6;
    		font-family: "Goudy Bookletter 1911", sans-serif;
    		border-radius: 15px;
    		padding-top: 5px;
    		padding-bottom: 5px;
    		margin-bottom: 15px;
    	}

		input[type = "text"] {
			padding: 10px;
			border: solid 1px #1577A6;
			border-color: #1577A6;
			color: #1577A6;
			font-size: 16px;
			border-radius: 5px;
			margin-bottom: 5px;

		}
		input[type = "text"]:focus{
			border: solid 1px #000000;
		}

		input[type = "password"] {
			padding: 10px;
			border: solid 1px #1577a6;
			border-color: #1577A6;
			color: #1577A6;
			font-size: 16px;
			border-radius: 5px;
			margin-bottom: 20px;
		}

		input[type = "password"]:focus{
			border: solid 1px #1577A6;
		}

		#banner{
			width:45%;
			height:30px;
			-webkit-transfrom: skew(-20deg);
			transform: skew(-20deg);
			background-color: #C5C5C5;
			position:relative;
			left:10px;
			font-family: "Goudy Bookletter 1911", sans-serif;
			color: #C5C5C5;
			padding-top: 20px;
			padding-bottom: 30px;
			font-size: 30px;
			border-radius: 5px;
			margin-bottom: 15px;
			-webkit-animation-name: mymove2;
			-webkit-animation-duration: .75s;
			-webkit-animation-delay: .25s;
			-webkit-animation-direction:reverse;
			-webkit-animation-fill-mode:forwards;
			animation-name: mymove2;
			animation-duration: .75s;
			animation-delay: .25s;
			animation-direction:reverse;
			animation-fill-mode:forwards;
		}

		/* Chrome, Safari, Opera */
			#login {-webkit-animation-timing-function: ease-out;}

			/* Standard syntax */
			#login {animation-timing-function: ease-out;}

		#button{
			background-color: #1577A6;
			color: white;
			font-family: "Goudy Bookletter 1911", sans-serif;
			border-color: #1577A6;
			border-radius: 5px;
			height: 50px;
			width: 100px;
			font-size: 20px;
			margin-top: 15px;
			margin-left: 30px;
			margin-right: 30px;
		}

        table td {
            height: 50px;
            vertical-align: middle;
        }

        table td label
        {
            width: 150px;
            vertical-align: middle;
            display: inline-block;
            margin-bottom: 15px;
        }

        textarea {
            max-width: 570px; 
        }

/* Standard syntax */
	@keyframes mymove2 {
    	from {left: 10px; background-color: #1577A6; color: white;}
   	 	to {left: -300px; background-color: #ffffff; color: #ffffff;}
	}
    	</style>
        <meta charset="UTF-8">
        <title>Secure Login: Registration Form</title>
        <script type="text/JavaScript" src="js/sha512.js"></script> 
        <script type="text/JavaScript" src="js/forms.js"></script>
        <script src="js/jquery.js" type="text/javascript"></script>

        <script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>

        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
        <link rel="stylesheet" href="css/styles.css" />
    </head>
    <script type="application/javascript">



      function isNumberKey(evt)
          {
             var charCode = (evt.which) ? evt.which : event.keyCode
             if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
             return true;
          }

      function goBack()
          {
             window.location.href = "http://reponotice.com/index.php";
          }  

          // jQuery(function($) {
          //       $('#check_box').click(function() {
          //           //var cb1 = $('#check_box').is(':checked');
          //           var cb1 = $('#check_box').is(':checked');
          //           $('#license').prop('readOnly', !(cb1));
          //           // if (cb1 == $('#check_box').is(':checked')) {
          //           //     document.getElementById('#license').value = "No License Entered";
          //           // }
          //           // else
          //           // {
          //           //     document.getElementById('#license').value = "";
          //           // }
          //       });
          //   }); 

        //   function add123_post(){
        //   var xhr;
        //     if (window.XMLHttpRequest) {
        //         xhr = new XMLHttpRequest();
        //     }
        //     else if (window.ActiveXObject) {
        //         xhr = new ActiveXObject("Msxml2.XMLHTTP");
        //     }
        //     else {
        //         throw new Error("Ajax is not supported by this browser, Please use a compatible browser.");
        //     }
        //     $('#fade').show();
        //     $('#spinner').show();
        //   var form_97617_data = $("#form_97617").serialize(); // gets all data from your form

        // // check if any fields have been left out
        //       $.ajax({
        //         url : "add123.php",
        //         type: "POST",
        //         data: form_97617_data,
        //           success: function(data, textStatus, jqXHR)
        //           {
        //             $('#fade').hide();
        //           $('#spinner').hide();
        //               //data - response from server
        //               alert(data);
        //               // move to this page location after submit
        //               window.location.reload();
        //         },
        //       });
        // }
    </script>
    <body>
    <?php include_once("includes/analyticstracking_register.php") ?>
        <form action="add123_int_rec.php" method="post" name="form_97617" id="form_97617">
            <div style="margin-left:1cm;">
                <table align="center">
                    <tr>
                        <td valign="middle">
                            <label for="example">uuid_integration:</label>
                        </td>
                        <td>
                            <input type="text" name="uuid_integration" id="uuid_integration">
                        </td>
                    </tr>
            	   <tr>
                    <td>
                        <label for="example">dealership_finance_corp_name:</label>
                    </td>
                    <td>
                        <input type="text" name="dealership_finance_corp_name" id="dealership_finance_corp_name" />
                    </td>   
                   </tr>
                   
                    <tr>
                        <td>
                            <label for="example">dealership_finance_company_name:</label>
                        </td>
                        <td>
                            <input type="text" name="dealership_finance_company_name" id="dealership_finance_company_name" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">lien_holder_address:</label>
                        </td>
                        <td>
                            <input type="text" name="lien_holder_address" id="lien_holder_address" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">lien_holder_city:</label>
                        </td>
                        <td>
                            <input type="text" name="lien_holder_city" id="lien_holder_city" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="example">lien_holder_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="lien_holder_state" name="lien_holder_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">lien_holder_zip:</label>
                        </td>
                        <td>
                            <input type="text" name="lien_holder_zip" id="lien_holder_zip" onkeypress="return isNumberKey(this)" maxlength="10"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">lien_holder_phone_number:</label>
                        </td>
                        <td>
                            <input type="text" name="lien_holder_phone_number" id="lien_holder_phone_number"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">customer_account_number:</label>
                        </td>
                        <td>
                            <input type="text" name="customer_account_number" id="customer_account_number"/>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">first_owner_first_name:</label>
                        </td>
                        <td>
                            <input type="text" name="first_owner_first_name" id="first_owner_first_name" />
                        </td>
                    </tr>




                    <tr>
                        <td>
                            <label for="example">first_owner_middle_name:</label>
                        </td>
                        <td>
                            <input type="text" name="first_owner_middle_name" id="first_owner_middle_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">first_owner_last_name:</label>
                        </td>
                        <td>
                            <input type="text" name="first_owner_last_name" id="first_owner_last_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">first_owner_title_address:</label>
                        </td>
                        <td>
                            <input type="text" name="first_owner_title_address" id="first_owner_title_address" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">first_owner_title_city:</label>
                        </td>
                        <td>
                            <input type="text" name="first_owner_title_city" id="first_owner_title_city" />
                        </td>
                    </tr>
                                        <tr>
                        <td>
                            <label for="example">first_owner_title_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="first_owner_title_state" name="first_owner_title_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>







                    <tr>
                        <td>
                            <label for="example">first_owner_title_zip:</label>
                        </td>
                        <td>
                            <input type="text" name="first_owner_title_zip" id="first_owner_title_zip" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">second_owner_first_name:</label>
                        </td>
                        <td>
                            <input type="text" name="second_owner_first_name" id="second_owner_first_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">second_owner_middle_name:</label>
                        </td>
                        <td>
                            <input type="text" name="second_owner_middle_name" id="second_owner_middle_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">second_owner_last_name:</label>
                        </td>
                        <td>
                            <input type="text" name="second_owner_last_name" id="second_owner_last_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">second_owner_address:</label>
                        </td>
                        <td>
                            <input type="text" name="second_owner_address" id="second_owner_address" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">second_owner_city:</label>
                        </td>
                        <td>
                            <input type="text" name="second_owner_city" id="second_owner_city" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="example">second_owner_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="second_owner_state" name="second_owner_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>





                    <tr>
                        <td>
                            <label for="example">second_owner_zip:</label>
                        </td>
                        <td>
                            <input type="text" name="second_owner_zip" id="second_owner_zip" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">third_owner_first_name:</label>
                        </td>
                        <td>
                            <input type="text" name="third_owner_first_name" id="third_owner_first_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">third_owner_middle_name:</label>
                        </td>
                        <td>
                            <input type="text" name="third_owner_middle_name" id="third_owner_middle_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">third_owner_last_name:</label>
                        </td>
                        <td>
                            <input type="text" name="third_owner_last_name" id="third_owner_last_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">third_owner_address:</label>
                        </td>
                        <td>
                            <input type="text" name="third_owner_address" id="third_owner_address" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">third_owner_city:</label>
                        </td>
                        <td>
                            <input type="text" name="third_owner_city" id="third_owner_city" />
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <label for="example">third_owner_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="third_owner_state" name="third_owner_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>



                    <tr>
                        <td>
                            <label for="example">third_owner_zip:</label>
                        </td>
                        <td>
                            <input type="text" name="third_owner_zip" id="third_owner_zip" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">fourth_owner_first_name:</label>
                        </td>
                        <td>
                            <input type="text" name="fourth_owner_first_name" id="fourth_owner_first_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">fourth_owner_middle_name:</label>
                        </td>
                        <td>
                            <input type="text" name="fourth_owner_middle_name" id="fourth_owner_middle_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">fourth_owner_last_name:</label>
                        </td>
                        <td>
                            <input type="text" name="fourth_owner_last_name" id="fourth_owner_last_name" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">fourth_owner_address:</label>
                        </td>
                        <td>
                            <input type="text" name="fourth_owner_address" id="fourth_owner_address" />
                        </td>
                    </tr><tr>
                        <td>
                            <label for="example">fourth_owner_city:</label>
                        </td>
                        <td>
                            <input type="text" name="fourth_owner_city" id="fourth_owner_city" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="example">fourth_owner_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="fourth_owner_state" name="fourth_owner_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>



                    <tr>
                        <td>
                            <label for="example">fifth_owner_first_name:</label>
                        </td>
                        <td>
                            <input type="text" name="fifth_owner_first_name" id="fifth_owner_first_name" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="example">fifth_owner_middle_name:</label>
                        </td>
                        <td>
                            <input type="text" name="fifth_owner_middle_name" id="fifth_owner_middle_name" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">fifth_owner_last_name:</label>
                        </td>
                        <td>
                            <input type="text" name="fifth_owner_last_name" id="fifth_owner_last_name" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">fifth_owner_address:</label>
                        </td>
                        <td>
                            <input type="text" name="fifth_owner_address" id="fifth_owner_address" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">fifth_owner_city:</label>
                        </td>
                        <td>
                            <input type="text" name="fifth_owner_city" id="fifth_owner_city" />
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <label for="example">fifth_owner_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="fifth_owner_state" name="fifth_owner_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <label for="example">fifth_owner_zip:</label>
                        </td>
                        <td>
                            <input type="text" name="fifth_owner_zip" id="fifth_owner_zip" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">sixth_owner_first_name:</label>
                        </td>
                        <td>
                            <input type="text" name="sixth_owner_first_name" id="sixth_owner_first_name" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">sixth_owner_middle_name:</label>
                        </td>
                        <td>
                            <input type="text" name="sixth_owner_middle_name" id="sixth_owner_middle_name" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">sixth_owner_last_name:</label>
                        </td>
                        <td>
                            <input type="text" name="sixth_owner_last_name" id="sixth_owner_last_name" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">sixth_owner_address:</label>
                        </td>
                        <td>
                            <input type="text" name="sixth_owner_address" id="sixth_owner_address" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">sixth_owner_city:</label>
                        </td>
                        <td>
                            <input type="text" name="sixth_owner_city" id="sixth_owner_city" />
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <label for="example">sixth_owner_state:</label>
                        </td>
                        <td>
                                <!-- Make the formatting match the rest of the program inputs  -->
                                <select class="element select medium" id="sixth_owner_state" name="sixth_owner_state"> 
                                <option selected="selected" value=""></option>
                                <option value="Alabama">Alabama</option>
                                <option value="Alaska">Alaska</option>
                                <option value="Arizona">Arizona</option>
                                <option value="Arkansas">Arkansas</option>
                                <option value="California">California</option>
                                <option value="Colorado">Colorado</option>
                                <option value="Connecticut">Connecticut</option>
                                <option value="Delaware">Delaware</option>
                                <option value="District Of Columbia">District Of Columbia</option>
                                <option value="Florida">Florida</option>
                                <option value="Georgia">Georgia</option>
                                <option value="Hawaii">Hawaii</option>
                                <option value="Idaho">Idaho</option>
                                <option value="Illinois">Illinois</option>
                                <option value="Indiana">Indiana</option>
                                <option value="Iowa">Iowa</option>
                                <option value="Kansas">Kansas</option>
                                <option value="Kentucky">Kentucky</option>
                                <option value="Louisiana">Louisiana</option>
                                <option value="Maine">Maine</option>
                                <option value="Maryland">Maryland</option>
                                <option value="Massachusetts">Massachusetts</option>
                                <option value="Michigan">Michigan</option>
                                <option value="Minnesota">Minnesota</option>
                                <option value="Mississippi">Mississippi</option>
                                <option value="Missouri">Missouri</option>
                                <option value="Montana">Montana</option>
                                <option value="Nebraska">Nebraska</option>
                                <option value="Nevada">Nevada</option>
                                <option value="New Hampshire">New Hampshire</option>
                                <option value="New Jersey">New Jersey</option>
                                <option value="New Mexico">New Mexico</option>
                                <option value="New York">New York</option>
                                <option value="North Carolina">North Carolina</option>
                                <option value="North Dakota">North Dakota</option>
                                <option value="Ohio">Ohio</option>
                                <option value="Oklahoma">Oklahoma</option>
                                <option value="Oregon">Oregon</option>
                                <option value="Pennsylvania">Pennsylvania</option>
                                <option value="Rhode Island">Rhode Island</option>
                                <option value="South Carolina">South Carolina</option>
                                <option value="South Dakota">South Dakota</option>
                                <option value="Tennessee">Tennessee</option>
                                <option value="Texas">Texas</option>
                                <option value="Utah">Utah</option>
                                <option value="Vermont">Vermont</option>
                                <option value="Virginia">Virginia</option>
                                <option value="Washington">Washington</option>
                                <option value="West Virginia">West Virginia</option>
                                <option value="Wisconsin">Wisconsin</option>
                                <option value="Wyoming">Wyoming</option>
                                </select>
                        </td>
                    </tr>


                    <tr>
                        <td>
                            <label for="example">sixth_owner_zip:</label>
                        </td>
                        <td>
                            <input type="text" name="sixth_owner_zip" id="sixth_owner_zip" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">vin:</label>
                        </td>
                        <td>
                            <input type="text" name="vin" id="vin" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">year:</label>
                        </td>
                        <td>
                            <select class="element select medium reqd" id="year" name="year"> 
                        <option selected="selected" value=""></option>
                        <?php
                        for ($i=date("Y")+1; $i >= 1900; $i--) { 
                            echo "<option value=".$i.">".$i."</option>";
                        }
                        ?>
                        </select>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="example">make:</label>
                        </td>
                        <td>
                            <input type="text" name="make" id="make" />
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="example">model:</label>
                        </td>
                        <td>
                            <input type="text" name="model" id="model" />
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="example">color:</label>
                        </td>
                        <td>
                            <input type="text" name="color" id="color" />
                        </td>
                    </tr>






                    <tr align="middle">
                        <td>
                        </td>
                        <td>
                            <input type="submit" class="btn btn-primary" value="submit data" />
                        </td>
                    </tr>
                </table>
                    </div>

        </form>
    </body>
</html>