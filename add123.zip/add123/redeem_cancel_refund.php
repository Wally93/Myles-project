<?php
require '../../includes/db_connect.php';
require '../../includes/functions.php';
sec_session_start();

$account_id = $_GET['account_id'];
$name_query = mysqli_query($con, "SELECT consumer_name FROM ".$_SESSION['table_link']." WHERE temp17='".$account_id."'");
$name=mysqli_result($name_query);

?>

<!DOCTYPE html>
<html>
<head>
	<title title="RepoNotice.com Your Convenient Reposession Document Management Solution">
	   RepoNotice.com Your Convenient Reposession Document Management Solution
	</title>
	<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- These are the formatting links for the table -->
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="../css/DT_bootstrap.css">

   <!-- Scripts for the tables auto resizing, search, etc... -->
    <script src="../js/jquery.js" type="text/javascript"></script>
    <script src="../js/bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../js/DT_bootstrap.js"></script>

    <script type="text/JavaScript" src="../js/sha512.js"></script>
    <script type="text/JavaScript" src="../js/forms.js"></script>

    <script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>

<style type="text/css">

html, body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
}
h1 {
    margin: 0;
    padding: 0;
}

.btn{
	width:250px;
}
</style>

<script type="text/javascript">
function get(q,s) {
    s = (s) ? s : window.location.search;
    var re = new RegExp('&amp;'+q+'=([^&amp;]*)','i');
    return (s=s.replace(/^\?/,'&amp;').match(re)) ?s=s[1] :s='';
}
	// function for adding a note to the customer inside the hidden nested tables

function redirect(){
      window.location.href = "../../subscriber_customertable/index.php";
}

function get_account_id(){
    var value1 = get('account_id');
    document.getElementById("account_id").value = value1;

}

function redeem_cancel_refund(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }

    var value1 = get('account_id');
    document.getElementById("account_id").value = value1;

    var form_data = $("#int_form").serialize(); // gets all data from your form

    $.ajax({
    url : "redeem_account.php",
    type: "POST",
    data: form_data,
      success: function(data, textStatus, jqXHR)
      {
      // closes the old window but creates the new redirected window before this happens  
      //alert(data);
      window.location.href = "integration_login.php";
    },
  });
}

</script>
</head>
<body onload="get_account_id()">
<form action="" method="post" id="int_form" name="int_form">
<input type="hidden" name="account_id" id="account_id" value=""/>
<br>
<center>	
<label><b>Click the option below. This will stop the automated process.</b></label>
    <br>
		<a onclick="redeem_cancel_refund()" class="btn btn-primary"><b>Customer Redeemed</b></a>
		<br>
		<br>
    <label><b>Account: <?php echo $name; ?></b></label>
</center>
</form>
</body>
</html>