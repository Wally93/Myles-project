<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
    header('location: ../../login.php');
    exit();
}
$account_id = $_POST['account_id'];

$sql = "UPDATE ".$_SESSION['table_link']." SET process_status='Redeemed' WHERE temp17='".$account_id."' AND (process_status='Notice Mailed' OR process_status='Notice Processed')";
$sql_response = mysqli_query($con, $sql)or die("The account you tried to change either cannot be changed at this point in the process or it does not exist, please review and try again.");

?>