<!DOCTYPE html>
<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
    header('location: ../../login.php');
    exit();
}
?>
<script type="text/javascript">

function vehicle_condition_report_form(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser, Please use a compatible browser.");
    }
  //var formdata = $("#def_form").serialize(); // gets all data from your form


  

  var vehicle_type = document.forms["vehicle_form"]["vehicle_type"].value;

  var form_data = $("#def_total_calc_form").serialize(); // gets all data from your form

  //var row_total = $("#row_total").val(); //will be the value of the total numbers of rows

// check if any fields have been left out
if (are_you_sure()) {
    $.ajax({
      url : "../../subscriber_deficiency/account_session_start.php",
      type: "POST",
      data: formData,
        success: function(data, textStatus, jqXHR)
        {
          //data - response from server
          //alert(row_id_num+"  and  "+c_name);
          // move to this page location after submit
          window.location.href = "../../subscriber_deficiency/"+vehicle_type+"_report.php";
          $('#fade').hide();
          $('#spinner').hide();
      },
    });
  };
}
	
</script>

<html lang='en'>
<head>
	<!-- These are the formatting links for the table -->
    <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">

   <!-- Scripts for the tables auto resizing, search, etc... -->
    <script src="../../js/jquery.js" type="text/javascript"></script>
    <script src="../../js/bootstrap.js" type="text/javascript"></script>
    <style type="text/css">
    	.btn { 
		    width:200px !important;
		    height:40px !important;
		 } 
    </style>

    <script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>
</head>
		<br>
		<br>
		<br>
		<br>
		<form id="vehicle_form" action="#####.php" name="vehicle_form" method="POST">
		<center><label><h2><font color="blue">Choose Your Vehicle Type Before We Get Started</font></h2></label></center>
		<div align="center">

		<label class="description" for="element_1">PLEASE SELECT VEHICLE TYPE:</label>
		<div>
			<select class="element select medium reqd" id="vehicle_type" name="vehicle_type">
			<option value="<?php echo @$subscriber_vehicle_type?>" selected="selected"><?php echo @$subscriber_vehicle_type?></option>
			<option value="motorcycle">Motor Cycle/Scooter/Moped</option>
			<option value="sedan">Sedan/Coupe</option>
			<option value="station_wagon">Station Wagon/Hatchback</option>
			<option value="suv">SUV</option>
			<option value="truck">Truck</option>
			<option value="van">Van</option>
			</select>
		</div> 

		<a class="btn btn-success" onclick="vehicle_condition_report_form()"><font size="3" color="blue">Submit</font></a>

		</div>
		<br>
		<br>
		
	</form>
</html>