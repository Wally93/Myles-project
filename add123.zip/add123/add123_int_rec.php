<?php
// require '../../includes/db_connect.php';
// require 'key_login/process_key_login.php';
require '../../includes/functions.php';
require_once("../../PHPMailer/class.PHPMailer.php");
require_once('../../PHPMailer/class.smtp.php');
// sec_session_start();
// if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
//     header('location: ../login.php');
//     exit();
// }

$uuid_integration = "";
$dealership_finance_corp_name = "";
$dealership_finance_company_name = "";
$lien_holder_address = "";
$lien_holder_city = "";
$lien_holder_state = "";
$lien_holder_zip = "";
$lien_holder_phone_number = "";
$customer_account_number = "";
$first_owner_first_name = "";
$first_owner_middle_name = "";
$first_owner_last_name = "";
$first_owner_title_address = "";
$first_owner_title_city = "";
$first_owner_title_state = "";
$first_owner_title_zip = "";
$second_owner_first_name = "";
$second_owner_middle_name = "";
$second_owner_last_name = "";
$second_owner_address = "";
$second_owner_city = "";
$second_owner_state = "";
$second_owner_zip = "";
$third_owner_first_name = "";
$third_owner_middle_name = "";
$third_owner_last_name = "";
$third_owner_address = "";
$third_owner_city = "";
$third_owner_state = "";
$third_owner_zip = "";
$fourth_owner_first_name = "";
$fourth_owner_middle_name = "";
$fourth_owner_last_name = "";
$fourth_owner_address = "";
$fourth_owner_city = "";
$fourth_owner_state = "";
$fourth_owner_zip = "";
$fifth_owner_first_name = "";
$fifth_owner_middle_name = "";
$fifth_owner_last_name = "";
$fifth_owner_address = "";
$fifth_owner_city = "";
$fifth_owner_state = "";
$fifth_owner_zip = "";
$sixth_owner_first_name = "";
$sixth_owner_middle_name = "";
$sixth_owner_last_name = "";
$sixth_owner_address = "";
$sixth_owner_city = "";
$sixth_owner_state = "";
$sixth_owner_zip = "";
$vin = "";
$year = "";
$make = "";
$model = "";
$color = "";


    $uuid_integration = filter_input(INPUT_POST, 'uuid_integration', FILTER_SANITIZE_STRING);
    $dealership_finance_corp_name = filter_input(INPUT_POST, 'dealership_finance_corp_name', FILTER_SANITIZE_STRING);
    $dealership_finance_company_name = filter_input(INPUT_POST, 'dealership_finance_company_name', FILTER_SANITIZE_STRING);
    $lien_holder_address = filter_input(INPUT_POST, 'lien_holder_address', FILTER_SANITIZE_STRING);
    $lien_holder_city = filter_input(INPUT_POST, 'lien_holder_city', FILTER_SANITIZE_STRING);
    $lien_holder_state = filter_input(INPUT_POST, 'lien_holder_state', FILTER_SANITIZE_STRING);
    $lien_holder_zip = filter_input(INPUT_POST, 'lien_holder_zip', FILTER_SANITIZE_STRING);
    $lien_holder_phone_number = filter_input(INPUT_POST, 'lien_holder_phone_number', FILTER_SANITIZE_STRING);
    $customer_account_number = filter_input(INPUT_POST, 'customer_account_number', FILTER_SANITIZE_STRING);
    $first_owner_first_name = filter_input(INPUT_POST, 'first_owner_first_name', FILTER_SANITIZE_STRING);
    $first_owner_middle_name = filter_input(INPUT_POST, 'first_owner_middle_name', FILTER_SANITIZE_STRING);
    $first_owner_last_name = filter_input(INPUT_POST, 'first_owner_last_name', FILTER_SANITIZE_STRING);
    $first_owner_title_address = filter_input(INPUT_POST, 'first_owner_title_address', FILTER_SANITIZE_STRING);
    $first_owner_title_city = filter_input(INPUT_POST, 'first_owner_title_city', FILTER_SANITIZE_STRING);
    $first_owner_title_state = filter_input(INPUT_POST, 'first_owner_title_state', FILTER_SANITIZE_STRING);
    $first_owner_title_zip = filter_input(INPUT_POST, 'first_owner_title_zip', FILTER_SANITIZE_STRING);
    $second_owner_first_name = filter_input(INPUT_POST, 'second_owner_first_name', FILTER_SANITIZE_STRING);
    $second_owner_middle_name = filter_input(INPUT_POST, 'second_owner_middle_name', FILTER_SANITIZE_STRING);
    $second_owner_last_name = filter_input(INPUT_POST, 'second_owner_last_name', FILTER_SANITIZE_STRING);
    $second_owner_address = filter_input(INPUT_POST, 'second_owner_address', FILTER_SANITIZE_STRING);
    $second_owner_city = filter_input(INPUT_POST, 'second_owner_city', FILTER_SANITIZE_STRING);
    $second_owner_state = filter_input(INPUT_POST, 'second_owner_state', FILTER_SANITIZE_STRING);
    $second_owner_zip = filter_input(INPUT_POST, 'second_owner_zip', FILTER_SANITIZE_STRING);
    $third_owner_first_name = filter_input(INPUT_POST, 'third_owner_first_name', FILTER_SANITIZE_STRING);
    $third_owner_middle_name = filter_input(INPUT_POST, 'third_owner_middle_name', FILTER_SANITIZE_STRING);
    $third_owner_last_name = filter_input(INPUT_POST, 'third_owner_last_name', FILTER_SANITIZE_STRING);
    $third_owner_address = filter_input(INPUT_POST, 'third_owner_address', FILTER_SANITIZE_STRING);
    $third_owner_city = filter_input(INPUT_POST, 'third_owner_city', FILTER_SANITIZE_STRING);
    $third_owner_state = filter_input(INPUT_POST, 'third_owner_state', FILTER_SANITIZE_STRING);
    $third_owner_zip = filter_input(INPUT_POST, 'third_owner_zip', FILTER_SANITIZE_STRING);
    $fourth_owner_first_name = filter_input(INPUT_POST, 'fourth_owner_first_name', FILTER_SANITIZE_STRING);
    $fourth_owner_middle_name = filter_input(INPUT_POST, 'fourth_owner_middle_name', FILTER_SANITIZE_STRING);
    $fourth_owner_last_name = filter_input(INPUT_POST, 'fourth_owner_last_name', FILTER_SANITIZE_STRING);
    $fourth_owner_address = filter_input(INPUT_POST, 'fourth_owner_address', FILTER_SANITIZE_STRING);
    $fourth_owner_city = filter_input(INPUT_POST, 'fourth_owner_city', FILTER_SANITIZE_STRING);
    $fourth_owner_state = filter_input(INPUT_POST, 'fourth_owner_state', FILTER_SANITIZE_STRING);
    $fourth_owner_zip = filter_input(INPUT_POST, 'fourth_owner_zip', FILTER_SANITIZE_STRING);
    $fifth_owner_first_name = filter_input(INPUT_POST, 'fifth_owner_first_name', FILTER_SANITIZE_STRING);
    $fifth_owner_middle_name = filter_input(INPUT_POST, 'fifth_owner_middle_name', FILTER_SANITIZE_STRING);
    $fifth_owner_last_name = filter_input(INPUT_POST, 'fifth_owner_last_name', FILTER_SANITIZE_STRING);
    $fifth_owner_address = filter_input(INPUT_POST, 'fifth_owner_address', FILTER_SANITIZE_STRING);
    $fifth_owner_city = filter_input(INPUT_POST, 'fifth_owner_city', FILTER_SANITIZE_STRING);
    $fifth_owner_state = filter_input(INPUT_POST, 'fifth_owner_state', FILTER_SANITIZE_STRING);
    $fifth_owner_zip = filter_input(INPUT_POST, 'fifth_owner_zip', FILTER_SANITIZE_STRING);
    $sixth_owner_first_name = filter_input(INPUT_POST, 'sixth_owner_first_name', FILTER_SANITIZE_STRING);
    $sixth_owner_middle_name = filter_input(INPUT_POST, 'sixth_owner_middle_name', FILTER_SANITIZE_STRING);
    $sixth_owner_last_name = filter_input(INPUT_POST, 'sixth_owner_last_name', FILTER_SANITIZE_STRING);
    $sixth_owner_address = filter_input(INPUT_POST, 'sixth_owner_address', FILTER_SANITIZE_STRING);
    $sixth_owner_city = filter_input(INPUT_POST, 'sixth_owner_city', FILTER_SANITIZE_STRING);
    $sixth_owner_state = filter_input(INPUT_POST, 'sixth_owner_state', FILTER_SANITIZE_STRING);
    $sixth_owner_zip = filter_input(INPUT_POST, 'sixth_owner_zip', FILTER_SANITIZE_STRING);
    $vin = filter_input(INPUT_POST, 'vin', FILTER_SANITIZE_STRING);
    $year = filter_input(INPUT_POST, 'year', FILTER_SANITIZE_STRING);
    $make = filter_input(INPUT_POST, 'make', FILTER_SANITIZE_STRING);
    $model = filter_input(INPUT_POST, 'model', FILTER_SANITIZE_STRING);
    $color = filter_input(INPUT_POST, 'color', FILTER_SANITIZE_STRING);


    $uuid_integration = str_replace("-","",$uuid_integration);

    //////////////////////////////////////////// email for the response from the html post to this link ////////////////////

        $mail             = new PHPMailer();

        $body             = "These are the fields that came through, the csv code will be revised and on the emails going forward after the revision they will be included.\n";   // main body
        $body = "<html>\n"; 
        $body .= "<body style='font-family:Verdana, Verdana, Geneva, sans-serif; font-size:15px; color:#666666;'>\n";
        $body .= "<p>uuid_integration: ".$uuid_integration."</p>";   // main body
        $body .= "<p>dealership_finance_corp_name: ".$dealership_finance_corp_name."</p>";   // main body
        $body .= "<p>dealership_finance_company_name: ".$dealership_finance_company_name."</p>";   // main body
        $body .= "<p>lien_holder_address: ".$lien_holder_address."</p>";   // main body
        $body .= "<p>lien_holder_city: ".$lien_holder_city."</p>";   // main body
        $body .= "<p>lien_holder_state: ".$lien_holder_state."</p>";   // main body
        $body .= "<p>lien_holder_zip: ".$lien_holder_zip."</p>";   // main body
        $body .= "<p>lien_holder_phone_number: ".$lien_holder_phone_number."</p>";   // main body
        $body .= "<p>customer_account_number: ".$customer_account_number."</p>";   // main body
        $body .= "<p>first_owner_first_name: ".$first_owner_first_name."</p>";   // main body
        $body .= "<p>first_owner_middle_name: ".$first_owner_middle_name."</p>";   // main body
        $body .= "<p>first_owner_last_name: ".$first_owner_last_name."</p>";   // main body
        $body .= "<p>first_owner_title_address: ".$first_owner_title_address."</p>";   // main body
        $body .= "<p>first_owner_title_city: ".$first_owner_title_city."</p>";   // main body
        $body .= "<p>first_owner_title_state: ".$first_owner_title_state."</p>";   // main body
        $body .= "<p>first_owner_title_zip: ".$first_owner_title_zip."</p>";   // main body
        $body .= "<p>second_owner_first_name: ".$second_owner_first_name."</p>";   // main body
        $body .= "<p>second_owner_middle_name: ".$second_owner_middle_name."</p>";   // main body
        $body .= "<p>second_owner_last_name: ".$second_owner_last_name."</p>";   // main body
        $body .= "<p>second_owner_address: ".$second_owner_address."</p>";   // main body
        $body .= "<p>second_owner_city: ".$second_owner_city."</p>";   // main body
        $body .= "<p>second_owner_state: ".$second_owner_state."</p>";   // main body
        $body .= "<p>second_owner_zip: ".$second_owner_zip."</p>";   // main body
        $body .= "<p>third_owner_first_name: ".$third_owner_first_name."</p>";   // main body
        $body .= "<p>third_owner_middle_name: ".$third_owner_middle_name."</p>";   // main body
        $body .= "<p>third_owner_last_name: ".$third_owner_last_name."</p>";   // main body
        $body .= "<p>third_owner_address: ".$third_owner_address."</p>";   // main body
        $body .= "<p>third_owner_city: ".$third_owner_city."</p>";   // main body
        $body .= "<p>third_owner_state: ".$third_owner_state."</p>";   // main body
        $body .= "<p>third_owner_zip: ".$third_owner_zip."</p>";   // main body
        $body .= "<p>fourth_owner_first_name: ".$fourth_owner_first_name."</p>";   // main body
        $body .= "<p>fourth_owner_middle_name: ".$fourth_owner_middle_name."</p>";   // main body
        $body .= "<p>fourth_owner_last_name: ".$fourth_owner_last_name."</p>";   // main body
        $body .= "<p>fourth_owner_address: ".$fourth_owner_address."</p>";   // main body
        $body .= "<p>fourth_owner_city: ".$fourth_owner_city."</p>";   // main body
        $body .= "<p>fourth_owner_state: ".$fourth_owner_state."</p>";   // main body
        $body .= "<p>fourth_owner_zip: ".$fourth_owner_zip."</p>";   // main body
        $body .= "<p>fifth_owner_first_name: ".$fifth_owner_first_name."</p>";   // main body
        $body .= "<p>fifth_owner_middle_name: ".$fifth_owner_middle_name."</p>";   // main body
        $body .= "<p>fifth_owner_last_name: ".$fifth_owner_last_name."</p>";   // main body
        $body .= "<p>fifth_owner_address: ".$fifth_owner_address."</p>";   // main body
        $body .= "<p>fifth_owner_city: ".$fifth_owner_city."</p>";   // main body
        $body .= "<p>fifth_owner_state: ".$fifth_owner_state."</p>";   // main body
        $body .= "<p>fifth_owner_zip: ".$fifth_owner_zip."</p>";   // main body
        $body .= "<p>sixth_owner_first_name: ".$sixth_owner_first_name."</p>";   // main body
        $body .= "<p>sixth_owner_middle_name: ".$sixth_owner_middle_name."</p>";   // main body
        $body .= "<p>sixth_owner_last_name: ".$sixth_owner_last_name."</p>";   // main body
        $body .= "<p>sixth_owner_address: ".$sixth_owner_address."</p>";   // main body
        $body .= "<p>sixth_owner_city: ".$sixth_owner_city."</p>";   // main body
        $body .= "<p>sixth_owner_state: ".$sixth_owner_state."</p>";   // main body
        $body .= "<p>sixth_owner_zip: ".$sixth_owner_zip."</p>";   // main body
        $body .= "<p>vin: ".$vin."</p>";   // main body
        $body .= "<p>year: ".$year."</p>";   // main body
        $body .= "<p>make: ".$make."</p>";   // main body
        $body .= "<p>model: ".$model."</p>";   // main body
        $body .= "<p>color: ".$color."</p>";   // main body
        $body .= "</body>\n"; 
        $body .= "</html>\n"; 
        $body             = wordwrap($body,80);         // wrap the body so that every 100 characters it will jump to a new line
        $body             = eregi_replace("[\]",'',$body);

        $mail->IsSMTP(true); // telling the class to use SMTP (may return error but is confirmed and working)
        // $mail->Host       = "west.exch080.serverdata.net.com"; // SMTP server
        //$mail->Host       = "mail.example.com"; // SMTP server
        //$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
                                                   // 1 = errors and messages
                                                   // 2 = messages only
        $mail->SMTPAuth   = true;                  // enable SMTP authentication
        $mail->SMTPSecure = "tls";                 // sets the prefix to the servier
        $mail->Host       = "173.194.207.108";      // sets GMAIL IP as the SMTP server
        $mail->Port       = 587;                   // set the SMTP port for the GMAIL server

        $mail->Username   = "regandrev@gmail.com";  // GMAIL username
        $mail->Password   = "8601Dixie@";            // GMAIL password

        $mail->SetFrom('admin@reponotice.com', 'Repo Notice Admin');
        $mail->AddReplyTo("admin@reponotice.com","Repo Notice Admin");

        //$mail->SetFrom('berserkforeal@gmail.com', 'Repo Notice Admin');
        //$mail->AddReplyTo("berserkforeal@gmail.com","Repo Notice Admin");

        $mail->Subject = "This is a test email for the integration platform";

        $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
        $mail->MsgHTML($body);                          // message body for email

        // $address_admin = "admin@reponotice.com";       // send to address
        // $mail->AddAddress($address_admin);    // send to address and name in the email

        // $other_address = "jkirkley@add123.com";       // send to address
        // $mail->AddAddress($other_address);    // send to address and name in the email

        $address_register = "admin@reponotice.com, jkirkley@add123.com";       // send to address
        // $mail2->AddAddress($address_register);    // send to address and name in the email
        //$address_register = "berserkforeal@gmail.com";       // send to address

        $recipients = explode(",", $address_register);
        foreach($recipients as $email)
        {
           $mail->AddBCC($email);
        }

        // $mail->AddAttachment('files/Please have this information available for your profile after approval.docx', 'Please have this information available for your profile after approval.docx');      // attachment

        //$mail->AddAttachment('files/Please have this information available for your profile after approval.pdf', 'Please have this information available for your profile after approval.pdf');      // attachment

        if(!$mail->Send()) {
          echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
          //echo "Message sent!";
        }

        ////////////////////////////////////////////////////////////////////////////////////// end of email ///////////////////////////

        // // # Title of the CSV
        // $Content = "uuid_integration, dealership_finance_corp_name, dealership_finance_company_name, lien_holder_address, lien_holder_city, lien_holder_state, lien_holder_zip, lien_holder_phone_number, customer_account_number, first_owner_first_name, first_owner_middle_name, first_owner_last_name, first_owner_title_address, first_owner_title_city, first_owner_title_state, first_owner_title_zip, second_owner_first_name, second_owner_middle_name, second_owner_last_name, second_owner_address, second_owner_city, second_owner_state, second_owner_zip, third_owner_first_name, third_owner_middle_name, third_owner_last_name, third_owner_address, third_owner_city, third_owner_state, third_owner_zip, fourth_owner_first_name, fourth_owner_middle_name, fourth_owner_last_name, fourth_owner_address, fourth_owner_city, fourth_owner_state, fourth_owner_zip, fifth_owner_first_name, fifth_owner_middle_name, fifth_owner_last_name, fifth_owner_address, fifth_owner_city, fifth_owner_state, fifth_owner_zip, sixth_owner_first_name, sixth_owner_middle_name, sixth_owner_last_name, sixth_owner_address, sixth_owner_city, sixth_owner_state, sixth_owner_zip, vin, year, make, model, color";

        // $Content .= "\n";

        // //set the data of the CSV
        // $Content .= "'".$uuid_integration."', '".$dealership_finance_corp_name."', '".$dealership_finance_company_name."', '".$lien_holder_address."', '".$lien_holder_city."', '".$lien_holder_state."', '".$lien_holder_zip."', '".$lien_holder_phone_number."', '".$customer_account_number."', '".$first_owner_first_name."', '".$first_owner_middle_name."', '".$first_owner_last_name."', '".$first_owner_title_address."', '".$first_owner_title_city."', '".$first_owner_title_state."', '".$first_owner_title_zip."', '".$second_owner_first_name."', '".$second_owner_middle_name."', '".$second_owner_last_name."', '".$second_owner_address."', '".$second_owner_city."', '".$second_owner_state."', '".$second_owner_zip."', '".$third_owner_first_name."', '".$third_owner_middle_name."', '".$third_owner_last_name."', '".$third_owner_address."', '".$third_owner_city."', '".$third_owner_state."', '".$third_owner_zip."', '".$fourth_owner_first_name."', '".$fourth_owner_middle_name."', '".$fourth_owner_last_name."', '".$fourth_owner_address."', '".$fourth_owner_city."', '".$fourth_owner_state."', '".$fourth_owner_zip."', '".$fifth_owner_first_name."', '".$fifth_owner_middle_name."', '".$fifth_owner_last_name."', '".$fifth_owner_address."', '".$fifth_owner_city."', '".$fifth_owner_state."', '".$fifth_owner_zip."', '".$sixth_owner_first_name."', '".$sixth_owner_middle_name."', '".$sixth_owner_last_name."', '".$sixth_owner_address."', '".$sixth_owner_city."', '".$sixth_owner_state."', '".$sixth_owner_zip."', '".$vin."', '".$year."', '".$make."', '".$model."', '".$color."'";

        // $Content .= "\n";

        $list = array
        (
        "uuid_integration, dealership_finance_corp_name, dealership_finance_company_name, lien_holder_address, lien_holder_city, lien_holder_state, lien_holder_zip, lien_holder_phone_number, customer_account_number, first_owner_first_name, first_owner_middle_name, first_owner_last_name, first_owner_title_address, first_owner_title_city, first_owner_title_state, first_owner_title_zip, second_owner_first_name, second_owner_middle_name, second_owner_last_name, second_owner_address, second_owner_city, second_owner_state, second_owner_zip, third_owner_first_name, third_owner_middle_name, third_owner_last_name, third_owner_address, third_owner_city, third_owner_state, third_owner_zip, fourth_owner_first_name, fourth_owner_middle_name, fourth_owner_last_name, fourth_owner_address, fourth_owner_city, fourth_owner_state, fourth_owner_zip, fifth_owner_first_name, fifth_owner_middle_name, fifth_owner_last_name, fifth_owner_address, fifth_owner_city, fifth_owner_state, fifth_owner_zip, sixth_owner_first_name, sixth_owner_middle_name, sixth_owner_last_name, sixth_owner_address, sixth_owner_city, sixth_owner_state, sixth_owner_zip, vin, year, make, model, color",
        "$uuid_integration, $dealership_finance_corp_name, $dealership_finance_company_name, $lien_holder_address, $lien_holder_city, $lien_holder_state, $lien_holder_zip, $lien_holder_phone_number, $customer_account_number, $first_owner_first_name, $first_owner_middle_name, $first_owner_last_name, $first_owner_title_address, $first_owner_title_city, $first_owner_title_state, $first_owner_title_zip, $second_owner_first_name, $second_owner_middle_name, $second_owner_last_name, $second_owner_address, $second_owner_city, $second_owner_state, $second_owner_zip, $third_owner_first_name, $third_owner_middle_name, $third_owner_last_name, $third_owner_address, $third_owner_city, $third_owner_state, $third_owner_zip, $fourth_owner_first_name, $fourth_owner_middle_name, $fourth_owner_last_name, $fourth_owner_address, $fourth_owner_city, $fourth_owner_state, $fourth_owner_zip, $fifth_owner_first_name, $fifth_owner_middle_name, $fifth_owner_last_name, $fifth_owner_address, $fifth_owner_city, $fifth_owner_state, $fifth_owner_zip, $sixth_owner_first_name, $sixth_owner_middle_name, $sixth_owner_last_name, $sixth_owner_address, $sixth_owner_city, $sixth_owner_state, $sixth_owner_zip, $vin, $year, $make, $model, $color",
        );

        # set the file name and create CSV file
        $FileName = "csv_push/".$uuid_integration."_add123_int_push_data.csv";
        $fd = fopen($FileName, "w");

        //fputs($fd, $Content);
        foreach ($list as $line)
      {
        fputcsv($fd,explode(',',$line));
      }

        fclose($fd);


        // $sql = "INSERT INTO ".$_SESSION['table_link']." (temp_id, subscribers_company_name_sos, subscribers_company_name, subscribers_buisness_address, subscribers_city, subscribers_state, subscribers_zip, subscribers_phone, consumer_vehicle_dealership, account_number, consumer_name, consumer_street_address, consumer_city, select_consumer_state, consumer_zip, consumer_social_security_number, consumer_birthdate, consumer_employer, consumer_work_phone, consumer_home_phone, consumer_cell_phone, consumer_bank, consumer_owns_property, is_there_a_cosign, cosigner_name, cosigner_street_address, cosigner_city, cosigner_state, cosigner_zip, cosigner_social_security_number, cosigner_birthdate, cosigner_employer, cosigner_work_phone, cosigner_home_phone, cosigner_cell_phone, cosigner_bank, cosigner_own_property, consumer_vehicle_vin, consumer_vehicle_year, consumer_vehicle_make, consumer_vehicle_model, consumer_vehicle_color, date_contract_signed, principal_balance_account_repo, reposession_fee, contract_interest_rate, temp8, repossession_date, frequency_of_payments, payment_amount, number_of_payments_past_due, temp17) VALUES ('".$uuid_integration."', '".$dealership_finance_corp_name."', '".$dealership_finance_company_name."', '".$lien_holder_address."', '".$lien_holder_city."', '".$lien_holder_state."', '".$lien_holder_zip."', '".$lien_holder_phone_number."', '".$customer_account_number."', '".$first_owner_first_name."', '".$first_owner_middle_name."', '".$first_owner_last_name."', '".$first_owner_title_address."', '".$first_owner_title_city."', '".$first_owner_title_state."', '".$first_owner_title_zip."', '".$second_owner_first_name."', '".$second_owner_middle_name."', '".$second_owner_last_name."', '".$second_owner_address."', '".$second_owner_city."', '".$second_owner_state."', '".$second_owner_zip."', '".$third_owner_first_name."', '".$third_owner_middle_name."', '".$third_owner_last_name."', '".$third_owner_address."', '".$third_owner_city."', '".$third_owner_state."', '".$third_owner_zip."', '".$fourth_owner_first_name."', '".$fourth_owner_middle_name."', '".$fourth_owner_last_name."', '".$fourth_owner_address."', '".$fourth_owner_city."', '".$fourth_owner_state."', '".$fourth_owner_zip."', '".$fifth_owner_first_name."', '".$fifth_owner_middle_name."', '".$fifth_owner_last_name."', '".$fifth_owner_address."', '".$fifth_owner_city."', '".$fifth_owner_state."', '".$fifth_owner_zip."', '".$sixth_owner_first_name."', '".$sixth_owner_middle_name."', '".$sixth_owner_last_name."', '".$sixth_owner_address."', '".$sixth_owner_city."', '".$sixth_owner_state."', '".$sixth_owner_zip."', '".$vin."', '".$year."', '".$make."', '".$model."', '".$color."')";
        //     $query = mysqli_query($con, $sql);
        //     if($query){
        //         // echo $times. " row inserted\n";
        //     }
        //     else{
        //         echo die(mysqli_error());
        //     }

        header("Location: https://www.reponotice.com/integration/add123/login_int.php?account_id=".$uuid_integration."");


// } // this is the end of the ip check if statement

?>