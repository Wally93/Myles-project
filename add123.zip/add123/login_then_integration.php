<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start(); // Our custom secure way of starting a PHP session.

if (isset($_POST['user_enter'], $_POST['p'])) 
{ 
    $email = $_POST['user_enter'];
    $password = $_POST['p']; // The hashed password.
    $account_id=$_POST['account_val'];
    if (login($email, $password, $mysqli) == true) {
        // Login success 
        //$_SESSION['int_account_id'] = $account_id;
        if ($_SESSION['first_timer'] === "yes") {
            header('Location: https://www.reponotice.com/integration/add123/terms/terms_and_cond.php?account_id='.$account_id);
        }
        else{
            header('Location: https://www.reponotice.com/integration/add123/integration_login.php?account_id='.$account_id);
        }
    }
    else {
        // Login failed
        header('Location: https://www.reponotice.com/integration/add123/login_int.php?error=1&account_id='.$account_id);
    }
} else {
    // The correct POST variables were not sent to this page. 
    echo 'Invalid Request';
}


?>