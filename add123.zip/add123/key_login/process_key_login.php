<?php
include_once '../../includes/psl-config.php';
// securly starts a session and checks for unauthenticated sessions
function sec_session_start() {
    $session_name = 'sec_session_id';   // Set a custom session name
    // rememebr for a production envrionment or basically when this is hosted online
    // change the $secure variable to true.
    $secure = SECURE;
    // This stops JavaScript being able to access the session id.
    $httponly = true;
    // Forces sessions to only use cookies.
    if (ini_set('session.use_only_cookies', 1) === FALSE) {
        header("Location: ../error.php?err=Could not initiate a safe session (ini_set)");
        exit();
    }
    // Gets current cookies params.
    $cookieParams = session_get_cookie_params();
    session_set_cookie_params(
        $cookieParams["lifetime"],
        $cookieParams["path"],
        $cookieParams["domain"],
        $secure,
        $httponly);
    // Sets the session name to the one set above.
    session_name($session_name);
    session_start();            // Start the PHP session 
    //session_regenerate_id(true);    // regenerated the session, delete the old one. 
}

// changed to use the username inside the database instead of the email, for more security

function login($email, $pubKey, $mysqli) {
    // Using prepared statements means that SQL injection is not possible. 
    if ($stmt = $mysqli->prepare("SELECT id, company_name, contact_name, username, email, password, state, phone, company_name_sos, salt, table_link, permission, first_timer, buisness_address, city, zip, attorney, certified_option FROM approved_users WHERE username = ? LIMIT 1")) {
        $stmt->bind_param('s', $email);  // Bind "$email" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
 
        // get variables from result.
        $stmt->bind_result($user_id, $company_name, $contact_name, $username, $email, $db_password, $state, $phone, $company_name_sos, $salt, $table_link, $permission, $first_timer, $buisness_address, $city, $zip, $attorney, $certified_option);
        $stmt->fetch();
 
        // hash the password with the unique salt.
        // $password = hash('sha512', $password.$salt);
        $pubKey_add = "AAAAB3NzaC1yc2EAAAADAQABAAABAQDCrGeaXfjB+idEtK5F43bO8YMQJ1VQtj3IMUVVEh6wgxH6NiGSNJVmaTq6WcoTDxD2+PG1bu6vT6OKUfqohRLfirbWu3LBYd6eeGaEBHhF6BFIXXYzXHY+pHgCqEZtobLamcsMVEUj6GW2Nyoae1Icc1o5YeczQpjagMWLa0jYKmJRzjNo56uodE0T661Bup3ZtNVLvzqrwSWdGeNn+RsMkCiNhOWX1Ai4bB51/U3aKtspegpTk/YCcum3I/SspkYymhfuj3zXgZOwrZ75Z7G6BnJP2Em5dVDyAy+eVJx+45PItwFX+X5/c/2iTyEB92RkzVSPZMb0HyAiwwh4ZUbP";

            if ($stmt->num_rows == 1)
            {
                // If the user exists we check if the account is locked
                if($permission === "<font color=red>locked<font>")
                {
                    // Account is locked 
                        // Send an email to user saying their account is locked
                        return false;
                }
                else{

                    // from too many login attempts 
                    if (checkbrute($user_id, $mysqli) == true) 
                    {
                        // Account is locked 
                        // Send an email to user saying their account is locked
                        return false;
                    }
                    else 
                    {
                        // Check if the password in the database matches
                        // the password the user submitted.
                        if ($pubKey == $pubKey_add) {
                            // Password is correct!
                            // Get the user-agent string of the user.
                            $user_browser = $_SERVER['HTTP_USER_AGENT'];
                            // XSS protection as we might print this value
                            $user_id = preg_replace("/[^0-9]+/", "", $user_id);
                            if ($first_timer === "yes") {
                                $_SESSION['first_timer'] = yes;
                            }
                            else{
                                $_SESSION['first_timer'] = no;
                            }
                            // set session variables up for the user to be able to start sessions
                            $_SESSION['user_id'] = $user_id;
                            $_SESSION['table_link'] = $table_link;
                            $_SESSION['email'] = $email;
                            $_SESSION['first_timer'] = $first_timer;
                            $_SESSION['certified_option'] = $certified_option;
                            ## set logged_in to true
                            $_SESSION['logged_in']= true;
                            // XSS protection as we might print this value
                            $username = preg_replace("/[^a-zA-Z0-9_\-]+/", "", $username);
                            $_SESSION['username'] = $username;
                            $_SESSION['login_string'] = hash('sha512', $password . $user_browser);
                            // Login successful.

                            $mySqlDate = date('Y-m-d');
                            $cordate = strtotime($mySqlDate);
                            $cordate = date('m-d-Y', $cordate);
                            $mySqlTime = date('g:i:s a');
                            $cortime = strtotime($mySqlTime);
                            $cortime = date('g:i:s A', $cortime);

                            $complete_time = $cordate.", ".$cortime;

                            // Login Time for successful Login recorded.
                            $mysqli->query("UPDATE approved_users SET last_login='".$complete_time."' WHERE id='".$user_id."'");
                            return true;
                        }
                        else 
                        {
                            // Password is not correct
                            // We record this attempt in the database
                            $now = time();
                            $mysqli->query("INSERT INTO login_attempts(user_id, time) VALUES ('$user_id', '$now')");
                            return false;
                        }
                    }
                }
            }
            else
            {
                // No user exists.
                return false;
            }
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//check for brute force attacks with thousands of attempted logins as to keep the traffic down and prevent these attacks

function checkbrute($user_id, $mysqli) {
    // Get timestamp of current time 
    $now = time();
 
    // All login attempts are counted from the past 2 hours. 
    $valid_attempts = $now - (2 * 60 * 60);
 
    if ($stmt = $mysqli->prepare("SELECT time FROM login_attempts WHERE user_id = ? AND time > '$valid_attempts'")) {
        $stmt->bind_param('i', $user_id);
 
        // Execute the prepared query. 
        $stmt->execute();
        $stmt->store_result();
 
        // If there have been more than 5 failed logins 
        if ($stmt->num_rows > 5) {
            return true;
        } else {
            return false;
        }
    }
}

// login script that checks if the user is in the database for subscribers

function login_check($mysqli) {
    // Check if all session variables are set 
    if (isset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['login_string'])) {
 
        $user_id = $_SESSION['user_id'];
        $login_string = $_SESSION['login_string'];
        $username = $_SESSION['username'];
 
        // Get the user-agent string of the user.
        $user_browser = $_SERVER['HTTP_USER_AGENT'];
 
        if ($stmt = $mysqli->prepare("SELECT password FROM approved_users WHERE id = ? LIMIT 1")) {
            // Bind "$user_id" to parameter. 
            $stmt->bind_param('i', $user_id);
            $stmt->execute();   // Execute the prepared query.
            $stmt->store_result();
 
            if ($stmt->num_rows == 1) {
                // If the user exists get variables from result.
                $stmt->bind_result($password);
                $stmt->fetch();
                $login_check = hash('sha512', $password . $user_browser);
 
                if ($login_check == $login_string) {
                    // Logged In!!!! 
                    return true;
                } else {
                    // Not logged in 
                    return false;
                }
            } else {
                // Not logged in 
                return false;
            }
        } else {
            // Not logged in 
            return false;
        }
    } else {
        // Not logged in 
        return false;
    }
}

// date functions with added days input
// this function is for the print notice mainly

// date modification function, adds days to curent date
function add_days($days){
    $current_date = date('m-d-Y', strtotime("+".$days." days"));
    return $current_date;
}

// sanatize the php_self server variable

function esc_url($url) {
 
    if ('' == $url) {
        return $url;
    }
 
    $url = preg_replace('|[^a-z0-9-~+_.?#=!&;,/:%@$\|*\'()\\x80-\\xff]|i', '', $url);
 
    $strip = array('%0d', '%0a', '%0D', '%0A');
    $url = (string) $url;
 
    $count = 1;
    while ($count) {
        $url = str_replace($strip, '', $url, $count);
    }
 
    $url = str_replace(';//', '://', $url);
 
    $url = htmlentities($url);
 
    $url = str_replace('&amp;', '&#038;', $url);
    $url = str_replace("'", '&#039;', $url);
 
    if ($url[0] !== '/') {
        // We're only interested in relative links from $_SERVER['PHP_SELF']
        return '';
    } else {
        return $url;
    }
}

function format_state_name( $input, $format = 'name' ) {
    if( ! $input || empty( $input ) )
        return;

    $states = array (
        'AL'=>'Alabama',
        'AK'=>'Alaska',
        'AZ'=>'Arizona',
        'AR'=>'Arkansas',
        'CA'=>'California',
        'CO'=>'Colorado',
        'CT'=>'Connecticut',
        'DE'=>'Delaware',
        'DC'=>'District Of Columbia',
        'FL'=>'Florida',
        'GA'=>'Georgia',
        'HI'=>'Hawaii',
        'ID'=>'Idaho',
        'IL'=>'Illinois',
        'IN'=>'Indiana',
        'IA'=>'Iowa',
        'KS'=>'Kansas',
        'KY'=>'Kentucky',
        'LA'=>'Louisiana',
        'ME'=>'Maine',
        'MD'=>'Maryland',
        'MA'=>'Massachusetts',
        'MI'=>'Michigan',
        'MN'=>'Minnesota',
        'MS'=>'Mississippi',
        'MO'=>'Missouri',
        'MT'=>'Montana',
        'NE'=>'Nebraska',
        'NV'=>'Nevada',
        'NH'=>'New Hampshire',
        'NJ'=>'New Jersey',
        'NM'=>'New Mexico',
        'NY'=>'New York',
        'NC'=>'North Carolina',
        'ND'=>'North Dakota',
        'OH'=>'Ohio',
        'OK'=>'Oklahoma',
        'OR'=>'Oregon',
        'PA'=>'Pennsylvania',
        'RI'=>'Rhode Island',
        'SC'=>'South Carolina',
        'SD'=>'South Dakota',
        'TN'=>'Tennessee',
        'TX'=>'Texas',
        'UT'=>'Utah',
        'VT'=>'Vermont',
        'VA'=>'Virginia',
        'WA'=>'Washington',
        'WV'=>'West Virginia',
        'WI'=>'Wisconsin',
        'WY'=>'Wyoming',
    );

    foreach( $states as $abbr => $name ) {
        if ( preg_match( "/\b($name)\b/", ucwords( strtolower( $input ) ), $match ) )  {
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        }
        elseif( preg_match("/\b($abbr)\b/", strtoupper( $input ), $match) ) {                    
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        } 
    }
    return;
}

function format_state_abbr( $input, $format = 'abbr' ) {
    if( ! $input || empty( $input ) )
        return;

    $states = array (
        'AL'=>'Alabama',
        'AK'=>'Alaska',
        'AZ'=>'Arizona',
        'AR'=>'Arkansas',
        'CA'=>'California',
        'CO'=>'Colorado',
        'CT'=>'Connecticut',
        'DE'=>'Delaware',
        'DC'=>'District Of Columbia',
        'FL'=>'Florida',
        'GA'=>'Georgia',
        'HI'=>'Hawaii',
        'ID'=>'Idaho',
        'IL'=>'Illinois',
        'IN'=>'Indiana',
        'IA'=>'Iowa',
        'KS'=>'Kansas',
        'KY'=>'Kentucky',
        'LA'=>'Louisiana',
        'ME'=>'Maine',
        'MD'=>'Maryland',
        'MA'=>'Massachusetts',
        'MI'=>'Michigan',
        'MN'=>'Minnesota',
        'MS'=>'Mississippi',
        'MO'=>'Missouri',
        'MT'=>'Montana',
        'NE'=>'Nebraska',
        'NV'=>'Nevada',
        'NH'=>'New Hampshire',
        'NJ'=>'New Jersey',
        'NM'=>'New Mexico',
        'NY'=>'New York',
        'NC'=>'North Carolina',
        'ND'=>'North Dakota',
        'OH'=>'Ohio',
        'OK'=>'Oklahoma',
        'OR'=>'Oregon',
        'PA'=>'Pennsylvania',
        'RI'=>'Rhode Island',
        'SC'=>'South Carolina',
        'SD'=>'South Dakota',
        'TN'=>'Tennessee',
        'TX'=>'Texas',
        'UT'=>'Utah',
        'VT'=>'Vermont',
        'VA'=>'Virginia',
        'WA'=>'Washington',
        'WV'=>'West Virginia',
        'WI'=>'Wisconsin',
        'WY'=>'Wyoming',
    );

    foreach( $states as $abbr => $name ) {
        if ( preg_match( "/\b($name)\b/", ucwords( strtolower( $input ) ), $match ) )  {
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        }
        elseif( preg_match("/\b($abbr)\b/", strtoupper( $input ), $match) ) {                    
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        } 
    }
    return;
}

function format_state_name_underscore( $input, $format = 'name' ) {
    if( ! $input || empty( $input ) )
        return;

    $states = array (
        'AL'=>'Alabama',
        'AK'=>'Alaska',
        'AZ'=>'Arizona',
        'AR'=>'Arkansas',
        'CA'=>'California',
        'CO'=>'Colorado',
        'CT'=>'Connecticut',
        'DE'=>'Delaware',
        'DC'=>'District_Of_Columbia',
        'FL'=>'Florida',
        'GA'=>'Georgia',
        'HI'=>'Hawaii',
        'ID'=>'Idaho',
        'IL'=>'Illinois',
        'IN'=>'Indiana',
        'IA'=>'Iowa',
        'KS'=>'Kansas',
        'KY'=>'Kentucky',
        'LA'=>'Louisiana',
        'ME'=>'Maine',
        'MD'=>'Maryland',
        'MA'=>'Massachusetts',
        'MI'=>'Michigan',
        'MN'=>'Minnesota',
        'MS'=>'Mississippi',
        'MO'=>'Missouri',
        'MT'=>'Montana',
        'NE'=>'Nebraska',
        'NV'=>'Nevada',
        'NH'=>'New_Hampshire',
        'NJ'=>'New_Jersey',
        'NM'=>'New_Mexico',
        'NY'=>'New_York',
        'NC'=>'North_Carolina',
        'ND'=>'North_Dakota',
        'OH'=>'Ohio',
        'OK'=>'Oklahoma',
        'OR'=>'Oregon',
        'PA'=>'Pennsylvania',
        'RI'=>'Rhode_Island',
        'SC'=>'South_Carolina',
        'SD'=>'South_Dakota',
        'TN'=>'Tennessee',
        'TX'=>'Texas',
        'UT'=>'Utah',
        'VT'=>'Vermont',
        'VA'=>'Virginia',
        'WA'=>'Washington',
        'WV'=>'West_Virginia',
        'WI'=>'Wisconsin',
        'WY'=>'Wyoming',
    );

    foreach( $states as $abbr => $name ) {
        if ( preg_match( "/\b($name)\b/", ucwords( strtolower( $input ) ), $match ) )  {
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        }
        elseif( preg_match("/\b($abbr)\b/", strtoupper( $input ), $match) ) {                    
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        } 
    }
    return;
}

function format_state_abbr_underscore( $input, $format = 'abbr' ) {
    if( ! $input || empty( $input ) )
        return;

    $states = array (
        'AL'=>'Alabama',
        'AK'=>'Alaska',
        'AZ'=>'Arizona',
        'AR'=>'Arkansas',
        'CA'=>'California',
        'CO'=>'Colorado',
        'CT'=>'Connecticut',
        'DE'=>'Delaware',
        'DC'=>'District_Of_Columbia',
        'FL'=>'Florida',
        'GA'=>'Georgia',
        'HI'=>'Hawaii',
        'ID'=>'Idaho',
        'IL'=>'Illinois',
        'IN'=>'Indiana',
        'IA'=>'Iowa',
        'KS'=>'Kansas',
        'KY'=>'Kentucky',
        'LA'=>'Louisiana',
        'ME'=>'Maine',
        'MD'=>'Maryland',
        'MA'=>'Massachusetts',
        'MI'=>'Michigan',
        'MN'=>'Minnesota',
        'MS'=>'Mississippi',
        'MO'=>'Missouri',
        'MT'=>'Montana',
        'NE'=>'Nebraska',
        'NV'=>'Nevada',
        'NH'=>'New_Hampshire',
        'NJ'=>'New_Jersey',
        'NM'=>'New_Mexico',
        'NY'=>'New_York',
        'NC'=>'North_Carolina',
        'ND'=>'North_Dakota',
        'OH'=>'Ohio',
        'OK'=>'Oklahoma',
        'OR'=>'Oregon',
        'PA'=>'Pennsylvania',
        'RI'=>'Rhode_Island',
        'SC'=>'South_Carolina',
        'SD'=>'South_Dakota',
        'TN'=>'Tennessee',
        'TX'=>'Texas',
        'UT'=>'Utah',
        'VT'=>'Vermont',
        'VA'=>'Virginia',
        'WA'=>'Washington',
        'WV'=>'West_Virginia',
        'WI'=>'Wisconsin',
        'WY'=>'Wyoming',
    );

    foreach( $states as $abbr => $name ) {
        if ( preg_match( "/\b($name)\b/", ucwords( strtolower( $input ) ), $match ) )  {
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        }
        elseif( preg_match("/\b($abbr)\b/", strtoupper( $input ), $match) ) {                    
            if( 'abbr' == $format ){ 
                return $abbr;
            } 
            else return $name;
        } 
    }
    return;
}

function mysqli_result($res,$row=0,$col=0){ 
    $numrows = mysqli_num_rows($res); 
    if ($numrows && $row <= ($numrows-1) && $row >=0){
        mysqli_data_seek($res,$row);
        $resrow = (is_numeric($col)) ? mysqli_fetch_row($res) : mysqli_fetch_assoc($res);
        if (isset($resrow[$col])){
            return $resrow[$col];
        }
    }
    return false;
}

function clean($string) {
   return preg_replace('/[^A-Za-z0-9\/:.@-]/', ' ', $string); // Removes special chars.
}

function clean_no_period($string) {
   return preg_replace('/[^A-Za-z0-9]/', ' ', $string); // Removes special chars.
}

function addDate($date,$day)//add days
{
    $sum = strtotime(date("m/d/Y", strtotime("$date")) . " +".$day." days");
    $dateTo=date('m/d/Y',$sum);
    return $dateTo;
}

?>