<?php
require '../../includes/db_connect.php';
// require 'key_login/process_key_login.php';
require '../../includes/functions.php';
sec_session_start();

$val = false;
if ($val) {
    $onload = "";
    $action = "";
}
else {
    $onload = "onload='login_nos()'";
    $action = "login_then_integration.php";
}
?>

<!DOCTYPE html>
<html>
<head>
	<title title="RepoNotice.com Your Convenient Reposession Document Management Solution">
	   RepoNotice.com Your Convenient Reposession Document Management Solution
	</title>
	<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- These are the formatting links for the table -->
    <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="../../css/DT_bootstrap.css">

   <!-- Scripts for the tables auto resizing, search, etc... -->
    <script src="../../js/jquery.js" type="text/javascript"></script>
    <script src="../../js/bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../../js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../../js/DT_bootstrap.js"></script>

    <script type="text/JavaScript" src="../../js/sha512.js"></script>
    <script type="text/JavaScript" src="../../js/forms.js"></script>

    <script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>

<style type="text/css">

html, body {
    width: 100%;
    height: 98%;
    margin: 0;
    padding: 0;
}
h1 {
    margin: 0;
    padding: 0;
}

.btn{
	width:500px;
  margin-bottom: 0.1cm;
}

.btn {
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  border-radius: 0px;
  font-family: Arial;
  color: #000000;
  font-size: 33px;
  padding: 17px;
  background: #189ad7;
  border: solid #000000 8px;
  text-decoration: none;
}

.btn:hover {
  background: #75caff;
  text-decoration: none;
  color: #000000;
}

.container{
	width: 50%;
   	height: 50%;
	position:relative;
	/*background: url('img/integration_background.png') no-repeat;*/
	/*background:    url('img/integration_background.png') no-repeat;*/
	/*margin-top: -50px;*/
	/*background-size: 1920px 1080px;*/
   	
}

.row-full{
 width: 200px;
 position: relative;
 top: 10px;
 left: 200px;
}

</style>

<script type="text/javascript">

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get(q,s) {
    s = (s) ? s : window.location.search;
    var re = new RegExp('&amp;'+q+'=([^&amp;]*)','i');
    return (s=s.replace(/^\?/,'&amp;').match(re)) ?s=s[1] :s='';
}
	// function for adding a note to the customer inside the hidden nested tables
function begin_notice_with_data(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }

    var value1 = get('account_id');
    document.getElementById("account_id").value = value1;

    var form_data = $("#add123_form").serialize(); // gets all data from your form

    $.ajax({
    url : "populate_with_csv.php",
    type: "POST",
    data: form_data,
      success: function(data, textStatus, jqXHR)
      {
      // closes the old window but creates the new redirected window before this happens  
      //alert(data);
      window.location.href = "../../subscriber_notice_of_sale/index.php";
    },
  });
}

function checkdate(date_val){
	var date_regex = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/ ;
	if(!(date_regex.test(date_val)))
	{
	return false;
	}
	else{
		return true;
	}
}


function toggle_error() {
    var x = document.getElementById('myDIV');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

	// function for adding a note to the customer inside the hidden nested tables
function begin_def_with_data(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }

    var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; //January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd='0'+dd
	} 

	if(mm<10) {
	    mm='0'+mm
	} 

	today = mm+'/'+dd+'/'+yyyy;
	// document.write(today);

	var x = document.getElementById('demo_error').style.display = 'block';
	var y = document.getElementById('demo_good').style.display = 'block';

    var val = prompt("Enter The Repo Sale Date", today);
    if (val != null) {
    	if(checkdate(val)){
    		var x = document.getElementById('demo_error');
    		x.style.display = 'none';
			// document.getElementById("demo_good").innerHTML = "Hello " + val + "! How are you today?";

			var repo_sale_date = val;
			var value1 = get('account_id');
		    document.getElementById("account_id").value = value1;

		    var form_data = $("#add123_form").serialize(); // gets all data from your form

		    $.ajax({
		    url : "populate_with_csv_def.php",
		    type: "POST",
		    data: form_data + '&repo_sale_date=' + repo_sale_date,
		      success: function(data, textStatus, jqXHR)
		      {
		      // closes the old window but creates the new redirected window before this happens  
		      //alert(data);
		      window.location.href = "https://www.reponotice.com/subscriber_deficiency/calculate_def_total.php";
		    },
		  });

    	}
    	else{
    		var y = document.getElementById('demo_good');
    		y.style.display = 'none';
	    	document.getElementById("demo_error").innerHTML = "Error " + val + " is NOT a Valid Date. Try Again";
	    }
    }
}

function vehicle_condition_report_form(){
	$('#fade').show();
    $('#spinner').show();
   var form_data = $("#add123_form").serialize(); // gets all data from your form
	   $.ajax({
	     type: "POST",
	     url: "populate_with_csv_vehicle_report.php",
	     data: form_data
	   }).done(function( msg ) {
	   		var left = (screen.width/2)-(screen.width/5);
	  		var top = (screen.height/2)-(screen.height/4);
	     	var url = "vehicle_start_page.php";
	     	var windowName = "Confirm Your Selection";

	     window.open(url, windowName, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=700, height=600, top='+top+', left='+left);
	     $('#fade').hide();
	     $('#spinner').hide();
	   });
}

function bad_debt_insert(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }

    var value1 = get('account_id');
    document.getElementById("account_id").value = value1;

    var form_data = $("#add123_form").serialize(); // gets all data from your form

    $.ajax({
    url : "populate_with_csv_bad_debt.php",
    type: "POST",
    data: form_data,
      success: function(data, textStatus, jqXHR)
      {
      // closes the old window but creates the new redirected window before this happens  
      //alert(data);
      window.location.href = "../../subscriber_bad_debt/index.php";
    },
  });
}

function bankruptcy_insert(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }

    var value1 = get('account_id');
    document.getElementById("account_id").value = value1;

    var form_data = $("#add123_form").serialize(); // gets all data from your form

    $.ajax({
    url : "populate_with_csv_bankruptcy.php",
    type: "POST",
    data: form_data,
      success: function(data, textStatus, jqXHR)
      {
      // closes the old window but creates the new redirected window before this happens  
      //alert(data);
      window.location.href = "../../subscriber_bankruptcy_account/index.php";
    },
  });
}

function redeem_redirect(){
    var account_id = get('account_id');
      window.location.href = "https://www.reponotice.com/integration/add123/redeem_cancel_refund.php?account_id="+account_id;
}



function accont_statuses(){
      window.location.href = "../../subscriber_customertable/index.php";
}


function login_nos(){
    var value1 = get('account_id');
    document.getElementById("account_id").value = value1;

}

function enter(evt){
    if(event.keyCode == 13){
        $("#button_submit").click();
    }
}
</script>
</head>
    <body <?php echo $onload;?>>
<form action="<?php echo $action;?>" method="post" id="add123_form" name="add123_form">

<center>
  <img src="img/New_LOGO.png" height="200" width="800">
</center>

<input type="hidden" name="account_id" id="account_id" value=""/>

      <?php if (login_check($mysqli) == true) { ?>
        <div class="container">
				   <div class="row-full">
				     	<b><font color="green"><p id="demo_good"></p></font></b>
				        <b><font color="red"><p id="demo_error"></p></font></b>
						<a onclick="begin_notice_with_data()" class="btn btn-primary">Mail Certified Notice</a>
						<br>
						<a onclick="vehicle_condition_report_form()" class="btn btn-primary">Vehicle Condition Report</a>
						<br>
						<a onclick="begin_def_with_data()" class="btn btn-primary">Mail Explanation of Deficiency</a>
						<br>
						<a onclick="bad_debt_insert()" class="btn btn-primary">Charged Off or Skip Accounts</a>
						<br>
						<a onclick="accont_statuses()" class="btn btn-primary">Account List / Upload Docs</a>
						<br>
						<a onclick="redeem_redirect()" class="btn btn-primary">Redeemed or Cancel</a>
						<br>
						<a onclick="bankruptcy_insert()" class="btn btn-primary">Bankruptcy Assistance</a>
						<br>
				   </div>   
				</div>
<?php 
    } 
    else{
      echo '<meta http-equiv="refresh" content="0; url=https://www.reponotice.com/integration/add123/login_int.php?account_id='.$_POST['account_id'].'" />';
      //header("Location: https://www.reponotice.com/integration/integration_login.php?account_id=".$_GET['account_id']."");
    }
?>


</form>



<!-- <div id="addlist" class="alt1" style="padding:10px;">
    New list items are added to the bottom of the list.
    <br /><br />
</div> -->


</body>
</html>