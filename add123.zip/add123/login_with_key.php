<?php
include_once '../../includes/db_connect.php';
// require 'key_login/process_key_login.php';
require '../../includes/functions.php';
sec_session_start(); // Our custom secure way of starting a PHP session.

if (isset($_GET['username'], $_GET['key'])) 
{
    $email = $_GET['username'];
    $pubKey = $_GET['key']; // The hashed password.
    $account_id = $_GET['account_val'];

    if (login($email, $pubKey, $mysqli) == true) {
        // Login success
        header('Location: https://www.reponotice.com/integration/add123/integration_login.php?account_id='.$account_id);
    }
    else {
        // Login failed
        header('Location: https://www.reponotice.com/integration/add123/login_int.php?error=1');
    }
} else {
    // The correct POST variables were not sent to this page. 
    echo 'Invalid Request';
}


?>