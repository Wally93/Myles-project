<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
    header('location: ../../login.php');
    exit();
}
$account_id = $_POST['account_id'];

$repo_sale_date = $_POST['repo_sale_date'];

$data[0] = NULL;
$data[1] = NULL;
$data[2] = NULL;
$data[3] = NULL;
$data[4] = NULL;
$data[5] = NULL;
$data[6] = NULL;
$data[7] = NULL;
$data[8] = NULL;
$data[9] = NULL;
$data[10] = NULL;
$data[11] = NULL;
$data[12] = NULL;
$data[13] = NULL;
$data[14] = NULL;
$data[15] = NULL;
$data[16] = NULL;
$data[17] = NULL;
$data[18] = NULL;
$data[19] = NULL;
$data[20] = NULL;
$data[21] = NULL;
$data[22] = NULL;
$data[23] = NULL;
$data[24] = NULL;
$data[25] = NULL;
$data[26] = NULL;
$data[27] = NULL;
$data[28] = NULL;
$data[29] = NULL;
$data[30] = NULL;
$data[31] = NULL;
$data[32] = NULL;
$data[33] = NULL;
$data[34] = NULL;
$data[35] = NULL;
$data[36] = NULL;
$data[37] = NULL;
$data[38] = NULL;
$data[39] = NULL;
$data[40] = NULL;
$data[41] = NULL;
$data[42] = NULL;
$data[43] = NULL;
$data[44] = NULL;
$data[45] = NULL;
$data[46] = NULL;
$data[47] = NULL;
$data[48] = NULL;
$data[49] = NULL;
$data[50] = NULL;
$data[51] = NULL;
$data[52] = NULL;
$data[53] = NULL;
$data[54] = NULL;
$data[55] = NULL;
$data[56] = NULL;
$data[57] = NULL;
$data[58] = NULL;
$data[59] = NULL;
$data[60] = NULL;
$data[61] = NULL;
$data[62] = NULL;
$data[63] = NULL;
$data[64] = NULL;
$data[65] = NULL;
$data[66] = NULL;
$data[67] = NULL;
$data[68] = NULL;
$data[69] = NULL;
$data[70] = NULL;

// skip first row (these are usually headers that are skipped)

$firstRow = true;
if (($handle = fopen("C:/inetpub/wwwroot/integration/add123/csv_push/".$account_id."_add123_int_push_data.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 3000, ",")) !== FALSE) {
        if($firstRow) { 
            $firstRow = false; 
        }
        else {
            $csv_data = array();

            for ($i=0; $i < 67; $i++) { 
                $data[$i] = preg_replace('/[^A-Za-z0-9\.\/_ -]/', '', $data[$i]);
            }

            $csv_data['temp17']                          = $account_id; //uuid_integration
            $csv_data['subscribers_company_name_sos']    = $data[1];
            $csv_data['subscribers_company_name']        = $data[2];
            $csv_data['subscribers_buisness_address']    = $data[3];
            $csv_data['subscribers_city']                = $data[4];
            $csv_data['subscribers_state']               = $data[5];
            $csv_data['subscribers_zip']                 = $data[6];
            $csv_data['subscribers_phone']               = $data[7];
            $csv_data['account_number']                  = $data[8];
            $csv_data['consumer_name']                   = $data[9]." ".$data[10]." ".$data[11];
            // $csv_data['first_owner_middle_name']      = $data[10];
            // $csv_data['first_owner_last_name']        = $data[11];
            $csv_data['consumer_street_address']         = $data[12];
            $csv_data['consumer_city']                   = $data[13];
            $csv_data['consumer_state']                  = $data[14];
            $csv_data['consumer_zip']                    = $data[15];

            $csv_data['cosigner_name']                   = $data[16]." ".$data[17]." ".$data[18];
            // $csv_data['second_owner_middle_name']     = $data[18];
            // $csv_data['second_owner_last_name']       = $data[19];
            $csv_data['cosigner_street_address']         = $data[19];
            $csv_data['cosigner_city']                   = $data[20];
            $csv_data['cosigner_state']                  = $data[21];
            $csv_data['cosigner_zip']                    = $data[22];
        
            $csv_data['consumer_vehicle_vin']            = $data[23];
            $csv_data['consumer_vehicle_year']           = $data[24];
            $csv_data['consumer_vehicle_make']           = $data[25];
            $csv_data['consumer_vehicle_model']          = $data[26];
            $csv_data['consumer_vehicle_color']          = $data[27];


            if ($csv_data[$a]['cosigner_name'] != "" || $csv_data[$a]['cosigner_zip']  != "" || $csv_data[$a]['cosigner_state']  != "" || $csv_data[$a]['cosigner_city']  != "" || $csv_data[$a]['cosigner_street_address']  != "") {
                        $cosigner = "yes";
                    }
                    else{
                        $cosigner = "no";
                    }

                    if ($cosigner === "yes") {
                        $unique =  substr(preg_replace('/(0)\.(\d+) (\d+)/', '$3$1$2', microtime()), 0, -2);
                        $random_number = $unique.$random_number;

                        $unique =  substr(preg_replace('/(0)\.(\d+) (\d+)/', '$3$1$2', microtime()), 0, -2);
                        $random_number_cos = $unique;
                    }
                    else {
                       $unique =  substr(preg_replace('/(0)\.(\d+) (\d+)/', '$3$1$2', microtime()), 0, -2);
                        $random_number = $unique.$random_number;
                    }

                    $csv_data['temp_id']                         = $random_number;


            $sql = "INSERT INTO ".$_SESSION['table_link']." (temp_id, subscribers_company_name_sos, subscribers_company_name, subscribers_buisness_address, subscribers_city, subscribers_state, subscribers_zip, subscribers_phone, account_number, consumer_name, consumer_street_address, consumer_city, consumer_zip, is_there_a_cosign, cosigner_name, cosigner_street_address, cosigner_city, cosigner_state, cosigner_zip, consumer_vehicle_vin, consumer_vehicle_year, consumer_vehicle_make, consumer_vehicle_model, consumer_vehicle_color, temp17) VALUES ('".$csv_data['temp_id']."', '".$csv_data['subscribers_company_name_sos']."', '".$csv_data['subscribers_company_name']."', '".$csv_data['subscribers_buisness_address']."', '".$csv_data['subscribers_city']."', '".$csv_data['subscribers_state']."', '".$csv_data['subscribers_zip']."', '".$csv_data['subscribers_phone']."', '".$csv_data['account_number']."', '".$csv_data['consumer_name']."', '".$csv_data['consumer_street_address']."', '".$csv_data['consumer_city']."', '".$csv_data['consumer_zip']."', '".$csv_data['is_there_a_cosign']."', '".$csv_data['cosigner_name']."', '".$csv_data['cosigner_street_address']."', '".$csv_data['cosigner_city']."', '".$csv_data['cosigner_state']."', '".$csv_data['cosigner_zip']."', '".$csv_data['consumer_vehicle_vin']."', '".$csv_data['consumer_vehicle_year']."', '".$csv_data['consumer_vehicle_make']."', '".$csv_data['consumer_vehicle_model']."', '".$csv_data['consumer_vehicle_color']."', '".$account_id."')";
            $query = mysqli_query($con, $sql);
            if($query){
                // echo $times. " row inserted\n";
            }
            else{
                echo die(mysqli_error());
            }
        }
    }
    fclose($handle);
}
elseif (($handle = fopen("C:/ftpRoot/add123sftp/".$account_id.".CSV", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 3000, ",")) !== FALSE) {
        if($firstRow) { 
            $firstRow = false; 
        }
        else {
            $csv_data = array();

            for ($i=0; $i < 67; $i++) { 
                $data[$i] = preg_replace('/[^A-Za-z0-9\.\/_ -]/', '', $data[$i]);
            }

            $csv_data['subscribers_company_name_sos']    = $data[0];
            $csv_data['subscribers_company_name']        = $data[1];
            $csv_data['subscribers_buisness_address']    = $data[2];
            $csv_data['subscribers_city']                = $data[3];
            $csv_data['subscribers_state']               = $data[4];
            $csv_data['subscribers_zip']                 = $data[5];
            $csv_data['subscribers_phone']               = $data[6];
            $csv_data['consumer_vehicle_dealership']     = $data[7];
            $csv_data['account_number']                  = $data[8];
            $csv_data['consumer_name']                   = $data[9]." ".$data[11];
            $csv_data['consumer_street_address']         = $data[12];
            $csv_data['consumer_city']                   = $data[13];
            $csv_data['select_consumer_state']           = $data[14];
            $csv_data['consumer_zip']                    = $data[15];
            $csv_data['consumer_social_security_number'] = $data[16];

            $item1 = explode(" ", $data[17]);
            $csv_data['consumer_birthdate']              = $item1[0];
            $csv_data['consumer_employer']               = $data[18];

            $csv_data['consumer_work_phone']             = $data[19];
            $csv_data['consumer_home_phone']             = $data[20];
            $csv_data['consumer_cell_phone']             = $data[21];
            $csv_data['consumer_bank']                   = $data[22];
            $csv_data['consumer_owns_property']          = $data[23];

            if ($data[25] == "" && $data[27] == "") {
                if($data[58] == ""){
                    $csv_data['is_there_a_cosign'] = "no";
                }
                else {
                    $csv_data['is_there_a_cosign'] = "yes";
                    $cobuyer = "yes";
                }
            }
            else {
                $cosigner = "yes";
                $csv_data['is_there_a_cosign'] = "yes";
            }

            if ($cobuyer == "yes") {

                $csv_data['cosigner_name']                   = $data[58]." ".$data[59]." ".$data[60];
                $csv_data['cosigner_street_address']         = $data[61];
                $csv_data['cosigner_city']                   = $data[62];
                $csv_data['cosigner_state']                  = $data[63];
                $csv_data['cosigner_zip']                    = $data[64];
                $csv_data['cosigner_social_security_number'] = $data[65];

                $item3 = explode(" ", $data[66]);
                $csv_data['cosigner_birthdate']              = $item3[0];

                $csv_data['cosigner_employer']               = $data[67];
                $csv_data['cosigner_work_phone']             = $data[68];
                $csv_data['cosigner_home_phone']             = $data[69];
                $csv_data['cosigner_cell_phone']             = $data[70];
                $csv_data['cosigner_bank']                   = $data[71];
                $csv_data['cosigner_own_property']           = $data[72];

            }
            else{

                $csv_data['cosigner_name']                   = $data[25]." ".$data[27];
                $csv_data['cosigner_street_address']         = $data[28];
                $csv_data['cosigner_city']                   = $data[29];
                $csv_data['cosigner_state']                  = $data[30];
                $csv_data['cosigner_zip']                    = $data[31];
                $csv_data['cosigner_social_security_number'] = $data[32];

                $item2 = explode(" ", $data[33]);
                $csv_data['cosigner_birthdate']              = $item2[0];

                $csv_data['cosigner_employer']               = $data[34];
                $csv_data['cosigner_work_phone']             = $data[35];
                $csv_data['cosigner_home_phone']             = $data[36];
                $csv_data['cosigner_cell_phone']             = $data[37];
                $csv_data['cosigner_bank']                   = $data[38];
                $csv_data['cosigner_own_property']           = $data[39];
            }
        
            $csv_data['consumer_vehicle_vin']            = $data[40];
            $csv_data['consumer_vehicle_year']           = $data[41];
            $csv_data['consumer_vehicle_make']           = $data[42];
            $csv_data['consumer_vehicle_model']          = $data[43];
            $csv_data['consumer_vehicle_color']          = $data[44];
            //$csv_data['consumer_vehicle_body_style']     = $data[45];

            $item3 = explode(" ", $data[46]);
            $csv_data['date_contract_signed']            = $item3[0];

            $csv_data['principal_balance_account_repo']  = $data[47];
            $csv_data['reposession_fee']                 = $data[48];
            $csv_data['contract_interest_rate']          = $data[49];
            $csv_data['temp8']                           = $data[50];
            $csv_data['repossession_date']               = $data[51];
            $csv_data['frequency_of_payments']           = $data[52];
            $csv_data['payment_amount']                  = $data[53];
            $csv_data['interest_rebate']                 = $data[54];

            $csv_data['number_of_payments_past_due']     = $data[73];

            $correct_principal_balance = $csv_data['principal_balance_account_repo']-$csv_data['interest_rebate'];

            if ($csv_data[$a]['cosigner_name'] != "" || $csv_data[$a]['cosigner_work_phone']  != "" || $csv_data[$a]['cosigner_home_phone']  != "" || $csv_data[$a]['cosigner_birthdate']  != "" || $csv_data[$a]['cosigner_social_security_number']  != "" || $csv_data[$a]['cosigner_zip']  != "" || $csv_data[$a]['cosigner_state']  != "" || $csv_data[$a]['cosigner_city']  != "" || $csv_data[$a]['cosigner_street_address']  != "") {
                        $cosigner = "yes";
                    }
                    else{
                        $cosigner = "no";
                    }

                    // if ($cosigner === "yes") {
                    //     do {
                    //         $random_number = rand(100000,9999999999);
                    //         $sql = "(SELECT temp_id FROM subscriber_table0 WHERE temp_id='".$random_number."')";
                    //         for ($i=0; $i < $table_count[0]-7; $i++){
                    //             $sql .= "UNION ALL (SELECT temp_id FROM subscriber_table".$i." WHERE temp_id='".$random_number."')";
                    //         }
                    //         $sql_response = mysqli_query($con, $sql)or die(mysqli_error($con));

                    //         $sql2 = "(SELECT temp_id_cos FROM subscriber_table0 WHERE temp_id_cos='".$random_number."')";
                    //         for ($i=0; $i < $table_count[0]-7; $i++){
                    //             $sql2 .= "UNION ALL (SELECT temp_id_cos FROM subscriber_table".$i." WHERE temp_id_cos='".$random_number."')";
                    //         }
                    //         $sql_response2 = mysqli_query($con, $sql2)or die(mysqli_error($con));

                    //     } while (mysqli_num_rows($sql_response) >= 1 || mysqli_num_rows($sql_response2) >= 1);

                    //     do {
                    //         $random_number_cos = rand(100000,9999999999);
                    //         $sql = "(SELECT temp_id FROM subscriber_table0 WHERE temp_id='".$random_number_cos."')";
                    //         for ($i=0; $i < $table_count[0]-7; $i++){
                    //             $sql .= "UNION ALL (SELECT temp_id FROM subscriber_table".$i." WHERE temp_id='".$random_number_cos."')";
                    //         }
                    //         $sql_response_cos = mysqli_query($con, $sql)or die(mysqli_error($con));

                    //         $sql2 = "(SELECT temp_id_cos FROM subscriber_table0 WHERE temp_id_cos='".$random_number_cos."')";
                    //         for ($i=0; $i < $table_count[0]-7; $i++){
                    //             $sql2 .= "UNION ALL (SELECT temp_id_cos FROM subscriber_table".$i." WHERE temp_id_cos='".$random_number_cos."')";
                    //         }
                    //         $sql_response_cos2 = mysqli_query($con, $sql2)or die(mysqli_error($con));

                    //     } while (mysqli_num_rows($sql_response_cos) >= 1 || mysqli_num_rows($sql_response_cos2) >= 1);
                    // }
                    // else {
                    //     do {
                    //         $random_number = rand(100000,9999999999);
                    //         $sql = "(SELECT temp_id FROM subscriber_table0 WHERE temp_id='".$random_number."')";
                    //         for ($i=0; $i < $table_count[0]-7; $i++){
                    //             $sql .= "UNION ALL (SELECT temp_id FROM subscriber_table".$i." WHERE temp_id='".$random_number."')";
                    //         }
                    //         $sql_response = mysqli_query($con, $sql)or die(mysqli_error($con));
                    //         $random_number_cos = 0;
                    //     } while (mysqli_num_rows($sql_response) >= 1);
                    // }

                    $unique =  substr(preg_replace('/(0)\.(\d+) (\d+)/', '$3$1$2', microtime()), 0, -2);
                    $random_number = $unique;

                    $csv_data['temp_id']                         = $random_number;
                    $consumer_name_val = $csv_data['consumer_name'];
                    $process_status = "Condition Report";

                    $cos_vals = $csv_data['is_there_a_cosign'];

                    $payed_for = "yes";

                    $has_account_been_repo_before = "unknown";

                    $proper_state = format_state_name($csv_data['select_consumer_state']);

            $sql = "INSERT INTO ".$_SESSION['table_link']." (temp_id, subscribers_company_name_sos, subscribers_company_name, subscribers_buisness_address, subscribers_city, subscribers_state, subscribers_zip, subscribers_phone, consumer_vehicle_dealership, account_number, consumer_name, consumer_street_address, consumer_city, select_consumer_state, consumer_zip, consumer_social_security_number, consumer_birthdate, consumer_employer, consumer_work_phone, consumer_home_phone, consumer_cell_phone, consumer_bank, consumer_owns_property, is_there_a_cosign, cosigner_name, cosigner_street_address, cosigner_city, cosigner_state, cosigner_zip, cosigner_social_security_number, cosigner_birthdate, cosigner_employer, cosigner_work_phone, cosigner_home_phone, cosigner_cell_phone, cosigner_bank, cosigner_own_property, consumer_vehicle_vin, consumer_vehicle_year, consumer_vehicle_make, consumer_vehicle_model, consumer_vehicle_color, date_contract_signed, principal_balance_account_repo, reposession_fee, contract_interest_rate, temp8, repossession_date, frequency_of_payments, payment_amount, number_of_payments_past_due, temp17, disposition_sale_date, consumer_vehicle_repo_sale_date, process_status, payed_for, table_link, has_account_been_repo_before) VALUES ('".$csv_data['temp_id']."', '".$csv_data['subscribers_company_name_sos']."', '".$csv_data['subscribers_company_name']."', '".$csv_data['subscribers_buisness_address']."', '".$csv_data['subscribers_city']."', '".$csv_data['subscribers_state']."', '".$csv_data['subscribers_zip']."', '".$csv_data['subscribers_phone']."', '".$csv_data['consumer_vehicle_dealership']."', '".$csv_data['account_number']."', '".$csv_data['consumer_name']."', '".$csv_data['consumer_street_address']."', '".$csv_data['consumer_city']."', '".$proper_state."', '".$csv_data['consumer_zip']."', '".$csv_data['consumer_social_security_number']."', '".$csv_data['consumer_birthdate']."', '".$csv_data['consumer_employer']."', '".$csv_data['consumer_work_phone']."', '".$csv_data['consumer_home_phone']."', '".$csv_data['consumer_cell_phone']."', '".$csv_data['consumer_bank']."', '".$csv_data['consumer_owns_property']."', '".$csv_data['is_there_a_cosign']."', '".$csv_data['cosigner_name']."', '".$csv_data['cosigner_street_address']."', '".$csv_data['cosigner_city']."', '".$csv_data['cosigner_state']."', '".$csv_data['cosigner_zip']."', '".$csv_data['cosigner_social_security_number']."', '".$csv_data['cosigner_birthdate']."', '".$csv_data['cosigner_employer']."', '".$csv_data['cosigner_work_phone']."', '".$csv_data['cosigner_home_phone']."', '".$csv_data['cosigner_cell_phone']."', '".$csv_data['cosigner_bank']."', '".$csv_data['cosigner_own_property']."', '".$csv_data['consumer_vehicle_vin']."', '".$csv_data['consumer_vehicle_year']."', '".$csv_data['consumer_vehicle_make']."', '".$csv_data['consumer_vehicle_model']."', '".$csv_data['consumer_vehicle_color']."', '".$csv_data['date_contract_signed']."', '".$correct_principal_balance."', '".$csv_data['reposession_fee']."', '".$csv_data['contract_interest_rate']."', '".$csv_data['temp8']."', '".$csv_data['repossession_date']."', '".$csv_data['frequency_of_payments']."', '".$csv_data['payment_amount']."', '".$csv_data['number_of_payments_past_due']."', '".$account_id."', '".$repo_sale_date."', '".$repo_sale_date."', '".$process_status."', '".$payed_for."', '".$_SESSION['table_link']."', '".$has_account_been_repo_before."')";
            $query = mysqli_query($con, $sql);
            if($query){
                // echo $times. " row inserted\n";
            }
            else{
                echo die(mysqli_error());
            }

            $temp_sql = "UPDATE ".$_SESSION['table_link']." SET
                        subscribers_id_number ='".$_SESSION['user_id']."',
                        subscribers_email = (SELECT email FROM approved_users WHERE id='".$_SESSION['user_id']."' AND email IS NOT NULL),
                        subscribers_company_name = (SELECT company_name FROM approved_users WHERE id='".$_SESSION['user_id']."' AND company_name IS NOT NULL),
                        subscribers_contact = (SELECT contact_name FROM approved_users WHERE id='".$_SESSION['user_id']."' AND contact_name IS NOT NULL),
                        subscribers_username = (SELECT username FROM approved_users WHERE id='".$_SESSION['user_id']."' AND username IS NOT NULL),
                        subscribers_state = (SELECT state FROM approved_users WHERE id='".$_SESSION['user_id']."' AND state IS NOT NULL),
                        subscribers_phone = (SELECT phone FROM approved_users WHERE id='".$_SESSION['user_id']."' AND phone IS NOT NULL),
                        subscribers_buisness_address = (SELECT buisness_address FROM approved_users WHERE id='".$_SESSION['user_id']."' AND buisness_address IS NOT NULL),
                        subscribers_company_name_sos = (SELECT company_name_sos FROM approved_users WHERE id='".$_SESSION['user_id']."' AND company_name_sos IS NOT NULL),
                        subscribers_city = (SELECT city FROM approved_users WHERE id='".$_SESSION['user_id']."' AND city IS NOT NULL),
                        subscribers_zip = (SELECT zip FROM approved_users WHERE id='".$_SESSION['user_id']."' AND zip IS NOT NULL)
                        WHERE temp_id='".$csv_data['temp_id']."'";
            if (!mysqli_query($con, $temp_sql)) {
                die('Error: ' . mysqli_error($con));
            }

        }
    }
    fclose($handle);
}

fclose($handle);

$_SESSION['integration_id'] = $random_number;
if(isset($consumer_name_val)){
    $_SESSION['def_consumer_name'] = $consumer_name_val;
}
if(isset($cos_vals)){
    $_SESSION['is_there_a_cosign'] = $cos_vals;
}



?>