<?php
require_once("../../PHPMailer/class.PHPMailer.php");
require_once('../../PHPMailer/class.smtp.php');
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
    header('location: ../integration_login.php');
    exit();
}
date_default_timezone_set('America/Chicago');
$accept_terms_var = "off";
$first_time = "no";

$cordate = date("l F, jS Y h:i:s A");

$sql="UPDATE approved_users SET confirm_terms='".$accept_terms_var."', date_terms_confirmed='".$cordate."', first_time='".$first_time."' WHERE id='".$_SESSION['user_id']."'";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}

// php mailer code for sending an email to the specified user
$mail = new PHPMailer();
$mail->IsHTML(true);

$body = "<html>\n";
$body .= "<body style='font-family:Verdana, Verdana, Geneva, sans-serif; font-size:15px; color:#666666;'>\n";

$body .= "<p>User With Id Number ".$_SESSION['user_id']." Did NOT Accept Terms And Conditions</p>"; // main body
$body .= "<p>User Name: ".$_SESSION['username']." </p>"; // main body
$body .= "<p>Email: ".$_SESSION['email']." </p>"; // main body
$body .= "<br>";  // main body

$body .= "</body>\n";
$body .= "</html>\n";

$body = eregi_replace("[\]",'',$body);

$mail->IsSMTP(true); // telling the class to use SMTP (may return error but is confirmed and working)
// $mail->Host       = "west.exch080.serverdata.net.com"; // SMTP server
//$mail->Host       = "mail.example.com"; // SMTP server
//$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "tls";                 // sets the prefix to the servier
$mail->Host       = "173.194.207.108";      // sets GMAIL IP as the SMTP server
$mail->Port       = 587;                   // set the SMTP port for the GMAIL server
$mail->Username   = "regandrev@gmail.com";  // GMAIL username
$mail->Password   = "8601Dixie@";            // GMAIL password

$mail->SetFrom('admin@reponotice.com', 'RepoNotice.com Admin');
$mail->AddReplyTo("admin@reponotice.com","RepoNotice.com Admin");

$mail->Subject    = "User ID ".$_SESSION['user_id']." Didnt Accept Terms";
$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);              // message body for email

$mail->AddBCC("admin@reponotice.com");

if(!$mail->Send()) {
  echo 'Mailer Error: ' . $mail->ErrorInfo;
}

$_SESSION['first_timer'] = "no";

?>