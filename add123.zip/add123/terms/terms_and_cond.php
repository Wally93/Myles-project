<!DOCTYPE html>
<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
    header('location: ../../login.php');
    exit();
}
?>
<html lang='en'>
<style type="text/css">
#fade {
    display: none;
    position:absolute;
    top: 0%;
    left: 0%;
    width: 100%;
    height: 100%;
    background-color: #ababab;
    z-index: 1001;
    -moz-opacity: 0.8;
    opacity: .70;
    filter: alpha(opacity=80);
}

#spinner{
   display: none;
    position: absolute;
    top: 45%;
    left: 45%;
    width: 64px;
    height: 64px;
    padding: 30px 30px 30px;
    border: 3px solid #ababab;
    box-shadow:1px 1px 10px #ababab;
    border-radius:20px;
    background-color: white;
    z-index: 1002;
    text-align:center;
    overflow: auto;
}
</style>
<head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <!-- This link is for the formatting on the navigation bar at the top -->
   <link rel="stylesheet" href="../../css/navbarform.css">
   <link rel="stylesheet" href="../../css/view.css">

   <!-- These are the formatting links for the table -->
    <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="../../css/DT_bootstrap.css">

    <script src="../../js/jquery.js" type="text/javascript"></script>
    <script src="../../js/bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../../js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../../js/DT_bootstrap.js"></script>
    
    <script src="../../view.js" type="text/javascript"></script>

    <script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>

</head>
<script type="text/javascript">

  function agree_to_terms(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }
    $('#fade').show();
    $('#spinner').show();
  var term_data = $("#form_976617").serialize(); // gets all data from your form
    $.ajax({
      url : "update_accept_terms.php",
      type: "POST",
      data: term_data,
        success: function(data, textStatus, jqXHR)
        {

        window.location.href = "https://www.reponotice.com/integration/integration_login.php?account_id="<?php echo $_POST['account_id']?>;
        $('#fade').hide();
          $('#spinner').hide();
      },
    });
}

function do_not_agree(){
  var xhr;
    if (window.XMLHttpRequest) {
        xhr = new XMLHttpRequest();
    }
    else if (window.ActiveXObject) {
        xhr = new ActiveXObject("Msxml2.XMLHTTP");
    }
    else {
        throw new Error("Ajax is not supported by this browser");
    }
    $('#fade').show();
    $('#spinner').show();
  var term_data = $("#form_976617").serialize(); // gets all data from your form
    $.ajax({
      url : "update_do_not_accept_terms.php",
      type: "POST",
      data: term_data,
        success: function(data, textStatus, jqXHR)
        {

        window.location.href = "https://www.reponotice.com/integration/integration_login.php?account_id="<?php echo $_POST['account_id']?>;
        $('#fade').hide();
          $('#spinner').hide();
      },
    });
}

</script>

<script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>

    <?php 
        $query=mysqli_query($con, "SELECT terms_and_conditions FROM reponotice_settings WHERE id='1'")or die(mysqli_error($con));
        if($row=mysqli_fetch_array($query)){
           $terms=$row['terms_and_conditions'];
       }
      ?>
<div id="fade"></div>
<img src="../../img/loading.gif" id="spinner"/>
<body id="main_body">
  <div id="form_container">
    <br>
    <center><h1><font color="steelblue">Please Read the Following Carefully Before Continuing</font></h1></center>
    <form id="form_976617" class="appnitro" enctype="multipart/form-data" method="POST" action="#######.php">
      
      <ul>

      <table width="100%"> 
      <tr align="middle">
          <td colspan="2">
              <textarea style="height:500px; width:100%"; disabled="disabled"><?php echo $terms;?></textarea>
          </td>
      </tr>
        

        </table>   
    </form>
    <div style="text-align: right">
        <a id="proc" name="proc" class="btn btn-large btn-primary" onclick="agree_to_terms()">Accept and Continue</a>
      </div>
      <br>
      <br>
      <br>
      <br>
      <div style="text-align: right">
        <a id="proc" name="proc" class="btn btn-large" onclick="do_not_agree()">Continue Without Accepting</a>
      </div>
    </ul>
  </div>
  </body>
</html>