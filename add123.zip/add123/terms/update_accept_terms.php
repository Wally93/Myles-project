<?php
include_once '../../includes/db_connect.php';
include_once '../../includes/functions.php';
sec_session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] == false){
    header('location: ../integration_login.php');
    exit();
}
date_default_timezone_set('America/Chicago');
$accept_terms_var = "off";

$cordate = date("l F, jS Y h:i:s A");

$first_time = "no";

$sql="UPDATE approved_users SET confirm_terms='".$accept_terms_var."', date_terms_confirmed='".$cordate."', first_time='".$first_time."' WHERE id='".$_SESSION['user_id']."'";

if (!mysqli_query($con,$sql)) {
  die('Error: ' . mysqli_error($con));
}

$_SESSION['first_timer'] = "no";

?>