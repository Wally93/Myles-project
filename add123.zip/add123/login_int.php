<?php
require '../../includes/db_connect.php';
require '../../includes/functions.php';

?>

<!DOCTYPE html>
<html>
<head>
    <title title="RepoNotice.com Your Convenient Reposession Document Management Solution">
       RepoNotice.com Your Convenient Reposession Document Management Solution
    </title>
    <head>
   <meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- These are the formatting links for the table -->
    <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css" media="screen">
    <link rel="stylesheet" type="text/css" href="../../css/DT_bootstrap.css">

   <!-- Scripts for the tables auto resizing, search, etc... -->
    <script src="../../js/jquery.js" type="text/javascript"></script>
    <script src="../../js/bootstrap.js" type="text/javascript"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../../js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8" language="javascript" src="../../js/DT_bootstrap.js"></script>

    <script type="text/JavaScript" src="../../js/sha512.js"></script>
    <script type="text/JavaScript" src="../../js/forms.js"></script>

    <script type="text/javascript">
        window.__lo_site_id = 78467;
        (function() {
                      var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
                      wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
                      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
        })();
    </script>

<style type="text/css">

/*html, body {
    width: 100%;
    height: 98%;
    margin: 0;
    padding: 0;
}
h1 {
    margin: 0;
    padding: 0;
}*/


.btn {
  -webkit-border-radius: 0;
  -moz-border-radius: 0;
  border-radius: 0px;
  font-family: Arial;
  color: #000000;
  font-size: 25px;
  padding: 17px;
  background: #189ad7;
  border: solid #000000 8px;
  text-decoration: none;
}

.btn:hover {
  background: #75caff;
  text-decoration: none;
  color: #000000;
}
.container{
    width: 100%;
    height: 110%;
    position:fixed;
    /*background: url('img/integration_background.png') no-repeat;*/
    /*background:    url('img/integration_background.png') no-repeat;*/
    margin-top: -50px;
    background-size: 1920px 1080px;
    
}

.row-full{
 width: 200px;
 position: fixed;
 top: 380px;
 left: 800px;
}

.row-left{
 width: 580px;
 position: fixed;
 top: 380px;
 left: 200px;
}

</style>

<script type="text/javascript">

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function get(q,s) {
    s = (s) ? s : window.location.search;
    var re = new RegExp('&amp;'+q+'=([^&amp;]*)','i');
    return (s=s.replace(/^\?/,'&amp;').match(re)) ?s=s[1] :s='';
}

function login_nos(){
  if(get('account_val')){
    var value1 = get('account_val');
    document.getElementById("account_val").value = value1;
  }
  else if(get('account_id')){
    var value1 = get('account_id');
    document.getElementById("account_val").value = value1;
  }
    

}

$(document).ready(function(){
    login_nos();
});

// document.addEventListener('DOMContentLoaded', function() {
//    // your code here
// }, false);
</script>

<center>
<form action="login_then_integration.php" method="post" id="int_form" name="int_form">


  <img src="img/New_LOGO.png" height="200" width="800">


<input type="hidden" name="account_val" id="account_val" value=""/>

<?php if (login_check($mysqli) == false) { ?>
<div class="container">
<!-- <label><font color="red" size="4">There was an error when loggin in, please enter your login credentials below.</font></label> -->
<div class="row-left">
<label><font size="6"><b>BHPH, LHPH, Special Finance,</b></font></label>
<label><font size="6"><b>and Subprime Auto Lenders</b></font></label>
<label><font size="6"><b>Welcome to Simple Automated Compliance that will Save You</b></font></label>
<label><font size="6"><b>Time and Make You Money</b></font></label>
  <br>
  <label><font size="6"><b>Toll free (844) Notice-1</b></font></label>
  <label><font size="6"><b>or (844) 668-4231 </b></font></label>
</div>
                   <div class="row-full">
            <table>
            <tr>
                <td>
                    <h2 type = "text">Username:</h2>
                </td>
                <td>
                    <input type="text" name="user_enter" id="user_enter"/>
                </td>
            </tr>
            <tr>
                <td>
                    <h2 type = "text">Password:</h2>
                </td>
                <td>
                     <input type="password" name="password" />
                </td>
            </tr>
            </table>
            <table width="380px">
            <tr>
                <td align="left">
                    <button class="btn btn-primary" type="button" value="Login" id="button_submit" onclick="formhash(this.form, this.form.password);">Secure Login</button>
                    
                </td>
                <td align="right">
                    <button class="btn btn-primary" type = "button" id="registerbtn" onclick="location.href='../profile_update/profile_int.php'">Free Registration</button>
                </td>
            </tr>
        </table>
        </div>   
                </div>
        <?php 
    } 
        else{
            echo '<meta http-equiv="refresh" content="0; url=https://www.reponotice.com/integration/add123/integration_login.php?account_id='.$_POST['account_id'].'" />';
            //header("Location: https://www.reponotice.com/integration/integration_login.php?account_id=".$_GET['account_id']."");
        }


        ?>

        </form>

        </center>

</body>
</html>